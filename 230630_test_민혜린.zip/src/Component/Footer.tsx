import React from "react";
import { styled } from "styled-components";

const Container = styled.div`
  width: 100%;
  display: flex;
  justify-content: center;
`;

const Button = styled.button`
  width: 90%;
  padding: 10px 0;
  margin: 10px 0;
  border: 1px solid rgba(0, 0, 220);
  border-radius: 10px;
  background-color: #fff;
  color: rgb(0, 0, 220);
  &:hover {
    box-shadow: 5px 5px 10px rgba(0, 0, 220, 0.2);
  }
`;

const Footer = ({ handleOnClick }) => {
  return (
    <Container>
      <Button onClick={handleOnClick}>가입하기</Button>
    </Container>
  );
};

export default Footer;
