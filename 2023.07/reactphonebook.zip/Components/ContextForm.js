import React from "react";
import "bootstrap/dist/css/bootstrap.min.css";
import { Button, Form } from "react-bootstrap";
import { useState } from "react";
import { useDispatch } from "react-redux";

const ContextForm = () => {
  const [name, setName] = useState(""); //입력될 값을 저장할 공간 및 변경값 저장
  const [phone, setPhone] = useState("");
  const getName = (e) => {
    setName(e.target.value);
  }; //인풋태그의 이벤트 함수 설정
  const getPhone = (e) => {
    setPhone(e.target.value);
  };

  const dispatch = useDispatch();
  const addContact = (e) => {
    e.preventDefault();
    dispatch({ type: "ADD_CONTACT", payload: { name, phone } });
  };
  return (
    <Form onSubmit={addContact}>
      <Form.Group className="mb-3" controlId="formName">
        <Form.Label>이름</Form.Label>
        <Form.Control
          value={name}
          onChange={getName}
          type="text"
          placeholder="이름을 입력해주세요"
        />
      </Form.Group>

      <Form.Group className="mb-3" controlId="formContact">
        <Form.Label>전화번호</Form.Label>
        <Form.Control
          value={phone}
          onChange={getPhone}
          type="text"
          placeholder="전화번호를 입력해주세요"
        />
      </Form.Group>
      <Button variant="primary" type="submit">
        추가
      </Button>
    </Form>
  );
};

export default ContextForm;
