import { srting1 } from "./MyClass1.js";
import { srting2 } from "./MyClass2.js";

srting1("오늘은 기분 좋은 날이에요!");
srting2("항상 그렇듯 늘 파이팅 입니다!");