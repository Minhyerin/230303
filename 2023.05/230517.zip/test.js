// 자동차 10부제 
// 자동차 끝번호 = 오늘 날짜의 마지막 숫자와 같으면 운행 불가

// 오늘 날짜 받기
// 차량번호 4자리 받기
// 해당차량 번호가 오늘 10부제에 걸리게 되면 오늘은 차량 운행 불가입니다 라고 알림창, 아니라면 안전운전하세요 알림창

let today = prompt("오늘은 몇일 인가요");
let carNumber = prompt("차량번호를 알려주세요");

function solution(e) {
  let take = carNumber.charAt(3); //해당인덱스의 값을 찾아오기
  if(e !== ""){ //값이 들어온다면
    if(e % 10 == take) {
      alert("오늘은 차량 운행 불가입니다");
    }
  } else {
    alert("안전 운전 하세요");
  }
}

solution(today);