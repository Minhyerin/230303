
// const arr = [20, 7, 23, 19, 10, 15, 25, 8, 13];
// //2개의 숫자 합이 40이 되는 숫자를 제외하고 콘솔창에 출력하기

// function solution(arr) {
//   let answer = arr;
//   let sum = answer.reduce((a, b) => a + b, 0);
//   console.log(sum)
//   for(let i = 0; i < 8; i++){
//     for(let j = i + 1; j < 9; j++){
//       if(sum - (answer[i] + answer[j]) == 100) {
//         answer.splice(j, 1);
//         answer.splice(i, 1);
//       }
//     }
//   }
//   return answer;
// }
// console.log(solution(arr));


const arr = ["teacher", "time", "student", "beautiful", "good"];
// 위 단어중 가장 긴 단어를 출력하기.
function solution(e) {
  let answer = "";
  // let max = Number.MIN_SAFE_INTEGER;
  let max = 0;
  for(let el of e){
    if(el.length > max){
      max = el.length;
      answer = el;
    }
  }
  return answer;
}

console.log(solution(arr))
//Number.Max_SAFE_INTEGER 자바스크립트의 최대값
//Number.Min_SAFE_INTEGER 자바스크립트의 최대값