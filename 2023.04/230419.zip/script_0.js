//내장 객체 3대장 *윈도우, 데이트, 수학객체

// 웹 브라우저의 최상위 객체 : window 객체
// 웹브라우저의 함수를 자바스크립트에서 썼을 뿐. 
// window.alert("hi") : window는 최상위객체니까(모든객체 앞에 다 써야하니까)생략가능.

// 콘솔창에 window 입력 -> f 가 있는건 함수.
// f가 없는 건 window 객체의 하위객체.
// screen, navigator, location
//window.open("popup.html", "popup1","width=360, height=490");

//(불러올 파일, 팝업이름, 사이즈 설정(px은 쓰지않음) 팝업이 나타날 위치) 팝업이름을 꼭 설정해야 팝업창이 별도로 뜨게된다.

// window.open("popup.html", "이벤트팝업", "width=600, height=500, left=300, top=100")

//window.innerWidth : 실제 출력되는 화면의 값
//window.width : 콘텐츠의 값
//window.print : 출력

//버튼 클릭시 팝업창 뜨기
// const btn = document.querySelector("button");
// const popWidth = 600;
// const popHeight = 500;
// // screen 객체 : 실제보고있는 화면의 대한 정보를 가져오는 객체
// btn.addEventListener("click", () => {
//   let left = (screen.availWidth - popWidth) / 2;
//   let top = (screen.availHeight - popHeight) / 2;
// //팝업창이 정중앙에 오도록 위치 설정
//   window.open("popup.html", "pop1", `width=${popWidth} height=${popHeight} left=${left} top=${top}`);
// })

// 사용자로부터 브라우저 데이터를 확인해서 데이터 값 출력하기
// let info = navigator.userAgent.toLowerCase(); //데이터를 소문자로 받겠다
// let osImg = null;

// if(info.indexOf('windows') >= 0) {
//   osImg = 'windows.png';
// } else if(info.indexOf('macintosh') >= 0) {
//   osImg = 'macintosh.png';
// } else if(info.indexOf('iphone') >= 0) {
//   osImg = 'iphone.png';
// } else if(info.indexOf('android') >= 0) {
//   osImg = 'android.png'
// }

// document.write("<img src=\"/img/"+ osImg +"\">", "<br />");
// let scr = screen;
// let sc_w = scr.width;
// let sc_h = scr.height;

// document.write("모니터 해상도 너비 : " + sc_w + "px", "<br/>");
// document.write("모니터 해상도 높이 : " + sc_h + "px", "<br/>");

//사용자로부터 아이디와, 비밀번호를 받아 확인하기
// let id = "today";
// let pw = "1234";

// let userId = prompt("당신의 아이디는?");
// if(id == userId){
//   let userPw = parseInt(prompt("당신의 비밀번호는?"));
//   if(pw == userPw) {
//     document.write(`${userId}님, 반갑습니다.`);
//   } else {
//     alert("비밀번호가 일치하지 않습니다.");
//     location.reload(); //새로고침
//   }
// } else {
//   alert("아이디가 일치하지 않습니다.");
//   location.reload();
// };

//마우스 커서 따라다니기 (제이쿼리)
let pointSize = $(".pointer").width();
$("#wrap").mousemove(function(e) {
  $(".pointer").css("top", e.pageY-pointSize);
  $(".pointer").css("left", e.pageX-pointSize);
  $(".pointer").fadeIn();
})

$("#wrap").on("mouseleave", function() {
  $(".pointer").fadeOut();
})