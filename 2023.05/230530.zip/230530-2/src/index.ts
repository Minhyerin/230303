
// //인덱스 시그니처
// type CountryCodes = {
//   [key: string]: string;
// };

// let countryCodes: CountryCodes = {
//   Korea : "ko",
//   UnitedState: "us",
//   UnitedKingdom: "uk"
// };

// //enum 타입
// enum Role {
//   ADMIN = 0,
//   USER = 1,
//   GUEST // value 값이 없어도 사용가능.(->순서대로값을 부여)
// }

// const user1 = {
//   name: "홍길동",
//   role: Role.ADMIN
// }
// const user2 = {
//   name: "김철수",
//   role: Role.USER
// }
// const user3 = {
//   name: "김민지",
//   role: Role.GUEST
// }
// console.log(user1, user2, user3);

// any 타입
let anyVar: any = 10;
anyVar = "hello";

let num:number = 10;
num = anyVar;
console.log(num);

// Unknown 타입
let unknownVar: unknown;
unknownVar = "";
unknownVar = 1;
unknownVar = () => {};

num = unknownVar; //불가능

// void 타입
function func1():string { //매개변수(인자값)도 타입정의 가능
  return "hello";
}
function func2():void { //무슨값이 들어올지 미정, 또는 지정하지 않는다
  console.log("hello");
}

let a:void;
a = 1; //할당불가
a = "hello" // 할당불가
a = undefined; //할당 가능

//그렇다면 null은 할당가능?
a = null;