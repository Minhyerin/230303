async function init() {
  const resoponse = await fetch('https://jsonplaceholder.typicode.com/users/');
  const users = await resoponse.json();
  display(users)
}

//테이블태그로 출력될수 있도록 함수
function display(users) {
  const result = document.querySelector("#result");
  let string = "";
  users.forEach((user) => {
    string += `
      <table>
        <tr><th>이름</th><td>${user.name}</td></tr>
        <tr><th>아이디</th><td>${user.username}</td></tr>
        <tr><th>이메일</th><td>${user.email}</td></tr>
      </table>
    `
  });
  result.innerHTML = string;
}
init();