// 이터레이터 & 제너레이터

// 문자열, 배열, Map, Set : 이터러블 객체
// *이터러블(iterable):순서대로 처리할 수 있는
// 이터레이터 객체를 프로토타입으로 상속을 받아야지만, 이터러블 객체가 될 수 있다.. 
// 이터러블객체의 특징
// 이터레블 객체 > next() 메서드 가지고있다 : 이터러블 객체에서 처음 실행했을때는 인덱스 첫번째 값 호출, next()메서드를 한번더 실행하면 그다음 인덱스 값을 호출한다..
// next() 언제쓸까? : 값을 호출할때, 한번에 값을 호출하지 않고, 순차적으로 값을 호출하고 싶을때..

// 생성자 함수 : 동일한 프로퍼티 혹은 객체를 다수 생성하고자 할때, 템플릿을 만들어놓고, 해당 템플릿을 통해서 효율적으로 객체를 만들고 싶기 때문에사용

//제너레이터 함수
// function* 함수명() {
//   yield key;
//   yield key;
//   yield key;
//   yield key;
// }
// yield = return과 같은 역할 함수가 끝나면 key값을 넘겨준다

// function* gen(){
//   yield 1;
//   yield 2;
//   yield 3;
// };
// let g1 = gen();
// // g1.next();
// // {value: 1, done: false}
// // g1.next();
// // {value: 2, done: false}
// // g1.next();
// // {value: 3, done: false}
// // g1.next();
// // {value: undefined, done: true}
// // g1
// // gen {<closed>}
// let g2 = gen();
// for(let i of g2) console.log(i);
// // 1
// // 2
// // 3
// let g3 = gen();
// g3.next()
// for(let i of g3) console.log(i);
// // 2
// // 3
