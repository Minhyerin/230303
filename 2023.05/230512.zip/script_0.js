// 사용자로 부터 이메일과 비밀번호를 받고 정보가 일치하는지 검증하는 함수 만들어보기

// const email = "email@naver.com";
// const pw = 1234;

// function login() {
//   const userEmail = prompt("이메일을 입력하세요");

//   if(userEmail !== null) {

//     if(userEmail === email) {
//       const userPw = parseInt(prompt("비밀번호를 입력하세요"));

//       if(userPw === pw) {
//         alert("로그인 되었습니다.");
//       } else {
//         alert("비밀번호가 틀렸습니다. 다시 입력해주세요");
//         location.reload();
//       }

//     } else {
//       alert("이메일이 틀렸습니다. 다시 입력해주세요");
//       location.reload();
//     }

//   } else {
//     alert("이메일을 입력하세요");
//     location.reload();
//   }
// }

// login();



// const result = document.querySelector("#result");
// const button = document.querySelector("button");

// button.addEventListener("click", (e) => {
//   e.preventDefault()
//   const number = Math.random();
//   const token = Math.floor(number * 1000000);
//   const paddentoken = String(token).padStart(6, "0");

//   result.innerHTML = paddentoken;

//   result.style.color = "#" + token;
// });


// //10부터 1까지 카운팅하기
// let time = 10;
// setInterval(function() {
//   if(time >= 0) {
//     console.log(time)
//     time = time - 1;
//   }
// }, 1000)


// // 3분 인증시간 카운팅
// let time = 180;

// setInterval(function() {
//   if(time >= 0) {
//     let min = Math.floor(time / 60);
//     let sec = time % 60;
//     console.log(min + ":" + String(sec).padStart(2, "0"));
//     time = time - 1;
//   }
// }, 1000)


let isStarted = false;

const result = document.querySelector("#result");
const button = document.querySelector("button");
const timer = document.querySelector("#timer");
const done = document.querySelector("#done");

const changeFocus1 = () => {
  let p1 = document.querySelector("#p1").value;
  if(p1.length === 3){
    document.querySelector("#p2").focus();
  }
}
const changeFocus2 = () => {
  let p2 = document.querySelector("#p2").value;
  if(p2.length === 4){
    document.querySelector("#p3").focus();
  }
}
const changeFocus3 = function() {
  let p1 = document.querySelector("#p1").value;
  let p2 = document.querySelector("#p2").value;
  let p3 = document.querySelector("#p3").value;

  if(p1 && p2 && p3) { 
    document.querySelector("#send").disabled = false;
  } else {
    document.querySelector("#send").disabled = true;
  }

  if(p3.length === 4) {
    document.querySelector("#send").focus();
  }
}

function solution() {
  if(isStarted === false) {
    // timer가 작동중이지 않을때
    isStarted = true;

    const token = String(Math.floor(Math.random() * 1000000)).padStart(6, "0");
    result.innerHTML = token;
    result.style.color = "#" + token;
  
    let time = 15;
  
    setInterval(function() {
    if(time >= 0) {
      let min = Math.floor(time / 60);
      let sec = String(time % 60).padStart(2, "0");
      timer.innerHTML = `${min} : ${sec}`;
      time = time - 1;
    } else {
      done.disabled = true;
      done.innerText = "인증시간 초과";
      isStarted = false;
    }
  }, 1000)
  } else {
    //timer 작동중일때
  }
}
