const result = document.querySelector("#result");
const button = document.querySelector("button");
const luckyNumber = {
  digitcount : 6,
  maxNumber : 45
};


button.addEventListener("click", () => {
  // let {digitcount, maxNumber} = luckyNumber;
  let myNumber = new Set();
  for(let i = 0; i < luckyNumber.digitcount; i++){
    myNumber.add(Math.floor((Math.random() * luckyNumber.maxNumber) + 1));
  }
  result.innerText = `${[...myNumber]}`;
});
