// 1.사용자로부터 값을 받는다
// 1-1 해당 숫자 개수가 1개 이상이면, 첫번째 숫자를 제외한 숫자를 화면에 출력
// 1-1 해당 숫자 개수가 1개이면 화면에 모두 출력
// 2.값을 받은 요소 출력
// 3. 첫번째 요소만 제외하고 출력

//나는 함수사용 안하고 if문으로햇는데

const origin = document.querySelector("#origin");
const result = document.querySelector("#result");
// 출력할 공간 정의
const num = prompt("숫자를 입력하세요");

origin.innerText = num;
// if(num.length > 1) { 
//   result.innerText = num.slice(1);
// } else if(num.length == 1) {
//   result.innerText = num;
// } else {
//   alert("숫자를입력하세요")
// }

// function tail(e) {
//   let n = "";
//   if(e.length > 1) {
//     n = e.slice(1);
//   } else {
//     n = e;
//   }
//   return n;
// }

const tail = (e) => {
  let sum = e.length > 1 ? e.slice(1) : e;
  return sum;
}
result.innerText = tail(num);