const btn = document.querySelector(".menu_toggle_btn");

btn.addEventListener("click", () => {
  document.querySelector(".gnb").classList.toggle("open");
});