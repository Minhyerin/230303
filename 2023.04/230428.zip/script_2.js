// *캔버스기능 => 소스코드를 활용하여 그림을 그릴 수 있는 기능 부여  , 자바스크립트 활용하여 그림과 애니메이션 구현

// *자바스크립트에서 캔버스 기능을 사용하기 위한 기본 셋팅
// 1) HTML 에 <canvas> 영역이 필요
// 2) 컨텍스트 설정 =  getContext() *프로그램에 특정 실행문을 호출하고 응답받을 수 있는 준비를 해 놓은 상태

// const canvas = document.querySelector("canvas");
// const ctx = canvas.getContext("2d");

// canvas.width = window.innerWidth;
// canvas.height = window.innerHeight;

// ctx.fillStyle = "rgb(200, 0, 0)";
// ctx.fillRect(10,10,100,100);

// 컴퓨터 프로그래밍 개발시 사용하는 각도 개념 = radian 
// 1radian = 180deg / PI 
// 1deg = PI / 180deg

// Math.PI * 0.5 = 90deg
// Math.PI * 1.5 = 270deg
// Math.PI = 180deg
// Math.PI * 2 = 360deg(0deg)
// (Math.PI / 180) * 60 = 60deg

// *사각형을 그리는 메서드
// 1) fillRect(x, y, width, height) : 색상을 채우는 사각형
// 2) strokeRect(x, y, width, height) : 테두리만 있는 사각형
// 3) clearRect(x, y, width, height) : 특정 위치 및 사이즈의 사각영역을 지울때

const canvas = document.querySelector("canvas");
const ctx = canvas.getContext("2d");

// ctx.fillStyle = "rgb(200, 0, 0)";
// ctx.fillRect(10, 10, 200, 100);
// ctx.strokeStyle = "blue";
// ctx.strokeRect(10, 10, 200, 100);

// ctx.fillStyle = "rgba(0, 0, 200, 0.5)";
// ctx.fillRect(50, 50, 120, 100);

// ctx.clearRect(70, 80, 80, 45);

// *삼각형을 그리는 메서드
// 1) beginPath() : 사각형을 제외한 나머지 도형을 그리기위한 시그널
// 2) moveTo(x, y) : 도형을 그릴 때, 시작점을 정의하는 메서드
// 3) lineTo(x, y) : 시작점에서부터 (x, y)좌표값까지 직선 경로를 만들겠다고 선언하는 메서드
// 4) stroke() : 선에 대한 경로 설정 후 해당 메서드를 반드시 입력해야만 화면에 출력
// 5)fill() : 배경 설정 후 해당 메서드를 반드시 입력해야만 화면에 출력
// 6) closePath() : 사각형을 제외한 나머지 도형을 다 그렸다는 마지막 시그널


// ctx.beginPath();
// ctx.moveTo(50, 50);
// ctx.lineTo(200, 200);
// ctx.stroke();
// ctx.closePath();

// ctx.beginPath();
// ctx.moveTo(350, 50);
// ctx.lineTo(200, 200);
// ctx.strokeStyle = "red"
// ctx.stroke();
// ctx.closePath();

// ctx.beginPath();
// ctx.moveTo(50, 50);
// ctx.lineTo(150, 100);
// ctx.lineTo(50, 150);
// ctx.closePath();
// ctx.stroke();

// ctx.beginPath();
// ctx.moveTo(150, 100);
// ctx.lineTo(250, 50);
// ctx.lineTo(250, 150);
// ctx.closePath();
// ctx.fillStyle = "rgb(0, 200, 0)";
// ctx.fill();
// ctx.stroke();

// *원 및 호를 그리는 메서드
// 1) arc(x, y, r, startAngle, endAngle, counterClockwise) 
// - x, y : 원의중심
// - r : 반지름
// - startAngle : 시작이 될 radian 값
// - endAngle :  마지막이 될 radian 값
// - counterClockwise : 반시계방향으로 도는 것을 기본값으로 인식 (true : 반시계, false : 시계)

// ctx.strokeStyle = "red";
// ctx.fillStyle = "yellow";

// ctx.beginPath();
// ctx.arc(200, 150, 100, 0, Math.PI * 2);
// ctx.stroke();
// ctx.fill();
// ctx.closePath();

// ctx.fillStyle = "red"

// ctx.beginPath();
// ctx.arc(120, 100, 50, 0, Math.PI, true);
// ctx.arc(280, 100, 50, 0, Math.PI, false);
// ctx.fill();
// ctx.closePath();

// ctx.beginPath();
// ctx.arc(120, 200, 50, (Math.PI /180) * 90, (Math.PI /180) * 270, false);
// ctx.closePath();
// ctx.stroke();

// ctx.strokeStyle = "blue"

// ctx.beginPath();
// ctx.arc(200, 200, 50, 0, (Math.PI /180) * 60, false);
// ctx.stroke();

// *타원을 그리는 메서드
// 1) ellipse(x, y, radiusX,  radiusY, rotation, stratAngle, endAngle, counterClockwise)
// - x, y : 타원의 중심
// - radiusX, radiusY : 타원의 가로 및 세로의 반지름
// - rotation : 타원의 회전각도
// *타원을 그리는 두번째 방법
// -기본적인 정원에 사이즈 변경을 통해 가능
// -scale(x, y)

// ctx.strokeStyle = "red";

// ctx.beginPath();
// ctx.ellipse(200, 70, 80, 50, 0, 0, Math.PI * 2);
// ctx.stroke();
// ctx.closePath();

// ctx.strokeStyle = "blue";

// ctx.beginPath();
// ctx.ellipse(150, 200, 80, 50, (Math.PI / 180) * -30, 0, Math.PI * 2);
// ctx.stroke();
// ctx.closePath();

// ctx.strokeStyle = "blue";
// ctx.scale(1, 0.7);

// ctx.beginPath();
// ctx.arc(200, 150, 80, 0, Math.PI * 2);
// ctx.stroke();
// ctx.closePath();

// // ctx.scale(1, 0.7);
// ctx.beginPath();
// ctx.arc(200, 150, 30, 0, Math.PI * 2);
// ctx.closePath();
// ctx.stroke();

// *곡선을 그리는 방법
// - 베지에 bezier
// - 2차 베지에 곡선 (조절점이 1개)
//   - quardraticCurveTo(cpx, cpy, x, y)
//   - cpx, cpy : 조절점 좌표
//   - x, y : 곡선이 끝나는 좌표
// - 3차 베지에 곡선 (조절점이 2개)
  // -bezierCurveTo(cpx1, cpy1, cpx2, cpy2, x, y)

// ctx.beginPath();
// ctx.moveTo(50, 100);
// ctx.quadraticCurveTo(100, 50, 150, 100);
// ctx.quadraticCurveTo(200, 150, 250, 100);
// ctx.quadraticCurveTo(300, 50, 350, 100);
// ctx.stroke();

// ctx.beginPath();
// ctx.moveTo(50, 100);
// ctx.bezierCurveTo(90, 250, 310, 10, 350, 100);
// ctx.stroke();

//인스턴스 객체를 사용하여 객체를 만들고 사용하기
// let triangle = new Path2D(); //내장객체
// triangle.moveTo(100, 100);
// triangle.lineTo(300, 100);
// triangle.lineTo(200, 260);
// triangle.closePath();

// let circle = new Path2D();
// circle.arc(200, 155, 50, 0, Math.PI*2);

// ctx.stroke(triangle);
// ctx.fillStyle = "green"
// ctx.fill(circle);

// ctx.scale(1, 0.9);
// /* Face */
// ctx.fillStyle = "green";
// ctx.strokeStyle = "black";
// ctx.beginPath();
// ctx.arc(150, 150, 80, 0, Math.PI * 2);
// ctx.fill();
// ctx.stroke();

// /* Eye */
// ctx.fillStyle = "white";
// ctx.strokeStyle = "green";
// ctx.beginPath();
// ctx.arc(120, 80, 20, 0, Math.PI * 2);
// ctx.moveTo(200, 80);
// ctx.arc(180, 80, 20, 0, Math.PI * 2);
// ctx.fill();
// ctx.stroke();

// ctx.fillStyle = "black";
// ctx.beginPath();
// ctx.arc(120, 80, 5, 0, Math.PI * 2);
// ctx.moveTo(200, 80);
// ctx.arc(180, 80, 5, 0, Math.PI * 2);
// ctx.fill();

// /* Mouth */
// ctx.strokeStyle = "black";
// ctx.lineWidth = 3;
// ctx.beginPath();
// ctx.arc(150, 150, 50, 0, Math.PI)
// ctx.stroke();

// *캔버스 텍스트 그리기
// - fillText(text, x, y) 
// - strokeText(text, x, y)
// - text :캔버스에 그릴 텍스트
// - x, y : 텍스트를 표시할 좌표

// ctx.strokeStyle = "red";
// ctx.font = "italic 60px serif"
// ctx.fillText("HELLO", 50, 70);
// ctx.font = "bold 60px sans-serif"
// ctx.strokeText("GOOD BYE", 50, 150);\

// *캔버스에 이미지 표시하기 => 내장객체 사용 (즉 인스턴스객체 활용)
// - drawImage(image, dx, dy)
// - image : 캔버스에 표시할 이미지 객체 타입 정의
// - dx, dy : 캔버스 좌측 상단으로 부터 얼마나 떨어진 지점에 표시할 것인가를 묻는 좌표값
// - drawImage(image, sx, sy, sw, sh, dx, dy, dw, dh)
// *이미지 클리핑
// - clip()

// let img = new Image();
// img.onload =  function(){
//   // ctx.drawImage(img, 0, 0, canvas.width, canvas.height) //사이즈도 정의가능
//   ctx.drawImage(img, 100, 50, 280, 350, 160, 100, 140, 175) //사이즈도 정의가능
// }//인스턴스 객체인 img에 불러온 이후에 함수 실행(문법처럼외우기)
// img.src = "/img/cat.jpg"

// let img = new Image();
// img.onload = function() {
//   ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
// }
// img.src = "/img/bird.jpg"
// ctx.beginPath();
// ctx.arc(250, 120, 100, 0, Math.PI * 2);
// ctx.clip();

// // *별그리기
// ctx.fillStyle = "orange"
// ctx.beginPath();
// ctx.moveTo(80, 100);
// ctx.lineTo(310, 100);
// ctx.lineTo(120, 250);
// ctx.lineTo(197, 30);
// ctx.lineTo(280, 250);
// ctx.lineTo(80, 100);
// ctx.closePath()
// ctx.fill();

let cat = new Image();
cat.onload = function() {
  ctx.drawImage(cat, 0, 0, canvas.width, canvas.height);
}
cat.src = "/img/cat.jpg";

ctx.beginPath();
ctx.ellipse(180, 150, 100, 140, 0, 0, Math.PI * 2);
ctx.clip();
