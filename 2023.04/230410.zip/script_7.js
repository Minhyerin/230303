$(function() {
  /*
  $(".btn1").on("click", function() {
    $(".txt1").animate({
      marginLeft:"500px",
      fontSize:"30px"
    }, 2000, "linear", function() {
      alert("모션 완료!")
    });
  });

  $(".btn2").on("click", function() {
    $(".txt2").animate({
      marginLeft:"+=50px"
    }, 1000);
  });
*/

/*
  $(".btn1").on("click", function() {
    $(".txt1")
    .animate({opacity:0.5}, 1000)
    .animate({marginLeft:"500px"}, 1000);
    $(".txt1").stop();
  });

  $(".btn2").on("click", function() {
    $(".txt2")
    .animate({opacity:0.5}, 1000)
    .animate({marginLeft:"500px"}, 1000);
    $(".txt2").stop(true, true);
  });
*/

  $(".txt1").animate({
    marginLeft:"300px"
  }, 1000);
  $(".txt2").delay(3000)
  .animate({
    marginLeft:"300px"
  }, 1000);

  $(".btn1").on("click", moveElement);
  function moveElement() {
    $(".txt3")
    .animate({marginLeft:"+=50px"}, 800);

    $(".txt4")
    .animate({marginLeft:"+=50px"}, 800);
    $(".txt4").stop();

    $(".txt5").animate({marginLeft:"+=50px"}, 800);
    $(".txt5").stop(true, true);
  }

  /*
  $(".txt1-1").animate({
    marginLeft:"200px"
  }, 1000)
  .animate({
    marginTop:"200px"
  }, 1000)
  .queue(function() {
    $(this).css({background:"red"});
    $(this).dequeue();
  }) //현재 적용되어있는 함수까지만 진행. 뒤에는 진행 X
  .animate({
    marginLeft:"0"
  }, 1000)
  .animate({
    marginTop:"0"
  }, 1000);
*/

  $(".txt1-1")
  .animate({marginLeft:"100px"}, 1000)
  .animate({marginLeft:"300px"}, 1000)
  .animate({marginLeft:"400px"}, 1000);

  $(".txt2-2")
  .animate({marginLeft:"100px"}, 1000)
  .animate({marginLeft:"300px"}, 1000)
  .animate({marginLeft:"400px"}, 1000);
  $(".txt2-2").clearQueue(); //처음 애니메이션만 진행. 뒤에는 진행X

  let txt6 = $(".txt6");
  let count = 1;
  $(".btnWrap button").on("click", function() {
    if(!txt6.is(":animated")) {
      if($(this).hasClass("backBtn")) {
        count--;
        if(count < 1) {
          count =  1;
          return false;
        }
        txt6.animate({marginLeft:"-=10%"}, 300);
      } else {
        count++;
        if(count > 10) {
          count = 10;
          return false;
        }
        txt6.animate({marginLeft:"+=10%"}, 300);
      }
    }
  });

  $("#btn").on("click", function() {
    $("h1").fadeOut(1000)
  });

  $("#btn_1").on("click", function() {
    $("#ctx").animate({ marginLeft:"+=50px"}, 500)
  });
});
