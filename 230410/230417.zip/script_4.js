const pic = document.querySelector("img");

pic.addEventListener("mouseover", ()=> {
  pic.src = `/img/pic-6.jpg`;
});
pic.addEventListener("mouseout", ()=> {
  pic.src = `/img/pic-1.jpg`;
});
