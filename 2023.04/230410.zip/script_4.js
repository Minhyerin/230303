$(function() {
  let baseFontSize = 14;
  $(".zoomBtnZone button").on("click", zoomInOut);
  function zoomInOut() {
    if($(this).hasClass("zoomOutBtn")) {
      //hasClass 선택된 선택자에 다음과 같은 클래스값이 존재한다면 참, 아니라면 거짓
      if(baseFontSize <= 8) return false;
      baseFontSize--;
    } else if($(this).hasClass("zoomInBtn")) {
      if(baseFontSize >= 20) return false;
      baseFontSize++;
    } else {
      baseFontSize = 14;
    }
    $(".fontSize").text(baseFontSize + "px");
    $("body")
    .css({
      fontSize : baseFontSize + "px"
    });
  };
})