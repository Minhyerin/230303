// 문자열 및 배열 

// 외부에서 데이터를 받아와서 가공하거나 편집할때 주로 많이 사용됨.

// 문자열 접근하기
//문자열에서 문자의 위치를 확인하는 2가지 메서드
// 1.chartAt()
// 2.indecOf()

// 1.chartAt()
// let str = "good morning";

// str.charAt(5); //매개변수 값의 해당하는 인덱스 문자열을 반환
// 'm'

// str.indexOf("m"); // 매개변수 값의 해당하는 문자의 인덱스값(넘버)을 반환
// 5

// 사용자로부터 특정텍스트를 수집하고, 해당 텍스트의 특정 문자가 몇번 사용되었는지 확인하는 프로그램 만들기
// const string = prompt("영어 문장을 입력하세요");
// const letter = prompt("어떤 문자를 체크하시겠습니까?");

// function counting(str, ch) {
//   let count = 0;

//   for(let i = 0; i < str.length; i++) {
//     if(str.charAt(i) === ch) {  //str[i]를 사용해도 값은 값이 나옴
//       count += 1;
//     }
//   }
//   return count;
// }

// const result = counting(string, letter);
// document.write(`${string}에는 ${letter} 이라는 문자가 ${result}개 있습니다.`);

// 2.indexOf()
// let str1 = "good morning everyone. beautiful morning";

// str1.indexOf("everyone");
// 13
// str1.indexOf("evening")
// -1 // 값이 없으면 무조건 -1 을 반환.

// let firstIndex = str1.indexOf("morning");
// firstIndex;
// 5
// str1.indexOf("morning", firstIndex+1);
// 33

//문자열에서 문자를 확인하는 3가지 메서드
// 1)startWith();
// 2)endsWith();
// 3)includes();

//1)startWith() 매개변수의 문자열으로 시작하는지 확인
// let str2 = "hello, everyone."
// str2.startsWith("hello");
// true
// str2.startsWith("Hello");
// false //대소문자구분
// str2.startsWith("he");
// true
// str2.startsWith("el", 1);
// true //첫번째 매개변수 : "el"라는 단어가있는지 , 두번째매개변수 : 인덱스넘버 (문자, 인덱스넘버) 특정 인덱스에 문자가 존재하는지

// //2)endsWith() 특정 문자열로 끝나는지 확인
// str2.endsWith("evryone.");
// true
// str2.endsWith("one.",16);
// true //(문자, 전체길이) 문자여르이 전체 길이 가운데 마지막 문자열에 해당 문자여부 확인할떼
// str2.endsWith("lo",5);
// true

// //응용
// str2.indexOf("even");
// -1
// str2.indexOf("every") !== -1;
// true // every 단어가 존재한다면?
// //3)includes //특정문자열에 문자가 존재하는지 확인 할때
// str2.includes("every");
// true


//문자열에서 공백을 제거하는 3가지메서드
// 1.trim()  // 문자열의 앞뒤 공백제거
// 2.trimStart()  //문자열의 앞 공백제거
// 3.trimEnd() //문자열의 뒤 공백 제거
// let str3 = " ab cd ef ";
// str3.trim();
// 'ab cd ef'
// str3.trimStart();
// 'ab cd ef 
// str3.trimEnd();
// ' ab cd ef'

//문자열에서 대소문자 바꾸는 2가지 메서드
// 1.toUpperCase() //문자열을 대문자로
// 2.toLowerCase() // 문자열을 소문자로
// let str4 = "Good morning";

// str4.toUpperCase();
// 'GOOD MORNING'
// str4.toLowerCase();
// 'good morning' 


//*중요) 문자열에서 특정문자열만 추출할때 사용하는 2가지 메서드
// // 1.subString(시작위치, 끝위치) //  시작위치부터 끝위치 직저까지의 문자열을 반환
// // 1-1.subString(시작위치) // 시작위치부터 끝까지 반환
// let str4 = "Good morning";
// str4.substring(5);
// 'morning'
// // 2.sliece(시작위치, 끝위치) //시작부터 끝위치 직전
// // 2-1.sliece(시작위치) //시작부터 끝까지
// str4.slice(0,4);
// 'Good'

// //다른점 : slice는 음수값을 사용 가능
// str4.slice(-5,12);
// 'rning'


//문자열에서 특정 구분자에 따라 문자를 쪼갤때 사용하는 메서드
// split(구분자)
// let str5 = "hello everyone";
// let array1 = str5.split(" ");
// array1;
// (2) ['hello', 'everyone']
// array1[1];
// 'everyone'

// //모든텍스트를 다 쪼갠다?
// let array2 = str5.split("");
// array2
// (14) ['h', 'e', 'l', 'l', 'o', ' ', 'e', 'v', 'e', 'r', 'y', 'o', 'n', 'e']