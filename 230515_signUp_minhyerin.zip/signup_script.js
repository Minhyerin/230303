
// 핸드폰 번호 입력
const changeFocus1 = () => {
  let p1 = document.querySelector("#p1").value;
  if(p1.length === 3){
    document.querySelector("#p2").focus();
  }
}
const changeFocus2 = () => {
  let p2 = document.querySelector("#p2").value;
  if(p2.length === 4){
    document.querySelector("#p3").focus();
  }
}
const changeFocus3 = function() {
  let p1 = document.querySelector("#p1").value;
  let p2 = document.querySelector("#p2").value;
  let p3 = document.querySelector("#p3").value;

  if(p1 && p2 && p3) { 
    document.querySelector("#send").disabled = false;
    send.style = "border : 1px solid #0068ff; color : #0068ff;"
  } else {
    document.querySelector("#send").disabled = true;
  }

  // if(p3.length === 4) {
  //   document.querySelector("#send").focus();
  // }
}

//인증번호 전송 클릭시, 인증번호 표시 및 타이머작동
const result = document.querySelector("#result");
//const button = document.querySelector("button");
const timer = document.querySelector("#timer");
const done = document.querySelector("#done");

let isStarted = false;
function tokenstart() {
  if(isStarted === false) {
    // timer가 작동중이지 않을때
    isStarted = true;

    const token = String(Math.floor(Math.random() * 1000000)).padStart(6, "0");
    result.innerHTML = token;
  
    let time = 30;
    setInterval(function timeclock() {
    if(time >= 0) {
      done.disabled = false;
      done.style = "border : 1px solid #0068ff; color : #0068ff;"
      let min = Math.floor(time / 60);
      let sec = String(time % 60).padStart(2, "0");
      timer.innerHTML = `${min}:${sec}`;
      time = time - 1;

    } else {
      done.disabled = true;
      done.innerText = "인증시간 초과";
      isStarted = false;
    }
  }, 1000)
  } else {
    //timer 작동중일때
  }
}
//인증완료 버튼 클릭시, 알림창
done.addEventListener("click", () => {
  alert("인증이 완료되었습니다.");
});

// 모든 정보 기입시 가입하기 버튼 활성화
const email = document.querySelector("#email");
const name = document.querySelector("#name").value;
const pw1 = document.querySelector("#pw1").value;
const pw2 = document.querySelector("#pw2").value;
const signUpBtn =  document.querySelector(".signup-bnt");
if(email && name && pw1 && pw2 && p1 && p2 && p3) {
  signUpBtn.disabled = "false"; 
} else {
  signUpBtn.disabled = "true"; 
}