// 노드를 만들어서 자녀요소로 추가
// > 가장 마지막영역에 추가됨
// >appendChild: 부모요소에 가자 ㅇ마지막 위치로 자녀를 편입시킴

// 기존노드의 앞에 새요소로 추가하고자 할때 사용하는 메서드 함수
// insertBefore(앞에 추가하고자하는 요소, 기준점이되는 요소)


// 텍스트 추가 버튼 클릭시 javascript 텍스트 앞에 typescript 단어가 추가되도록
// const button = document.querySelector("button"); //버튼을 정의

// let newP = document.createElement("p"); //새로운 요소 만들기
// let textNode = document.createTextNode("Typescript"); // 텍스트 노드 만들기
// newP.appendChild(textNode); //새로운요소안에 텍스트 노드를 하위요소로 넣기

// let basisNode = document.querySelectorAll("p")[2]; //기준점이 되는 요소를 정의

// button.addEventListener("click", () => { //버튼을 클릭하면
//   document.body.insertBefore(newP, basisNode); //기준점 요소 앞에 새로운 요소를 추가한다.
//   newP.style.color = "blue";
// })


// 노드 삭제하는 메서드
// remove(): 선택된 요소 및 노드 자체를 삭제.
// 삭제하고자 하는요소.remove()
// const title = document.querySelector("h1");
// title.addEventListener("click", () => {
//   title.remove();
// });

// removeChild() : 선택된 요소 및 노드의 자녀 노드를 삭제합니다.
// 부모노드를 찾는 프로퍼티 : 자식노드.parentNode
// 부모노드.removeChild(자녀노드);

const items = document.querySelectorAll("li");

for(let item of items) {
  item.addEventListener("click", function() { //화살표함수를 쓰면 작동안됨.
    this.parentNode.removeChild(this);
  });
};
// 화살표함수가 만능은아니다.. this 가 화살표함수에 들어오게 되면 Window 객체를 가르킴.. this객체를 사용해야할땐 화살표함수를 쓸 수 없다.