const url = "https://jsonplaceholder.typicode.com/comments";

document.querySelector("button"),addEventListener("click", (e) => {
  e.preventDefault();
  fetch(url)
  .then(response => response.json())
  .then(data => {
    const log = document.querySelector("#log");
    log.innerText = data;
  });
});
