const input = document.querySelector("input");
const btnSave = document.querySelector(".btnSave");
const btnRemove = document.querySelector(".btnRemove");
const btnClear = document.querySelector(".btnClear");

const key = "mykey";

btnSave.addEventListener("click", (e) => {
  e.preventDefault();
  localStorage.setItem(key, input.value);
  input.value = "";
});

btnRemove.addEventListener("click", (e) => {
  e.preventDefault();
  localStorage.removeItem(key);
});

btnClear.addEventListener("click", (e) => {
  e.preventDefault();
  localStorage.clear();
});