//date 객체 : 현 시점의 날짜, 년도, 월, 일, 요일 ,시간 등을 사용하고자 할 때 이용하는 내장객체
// > 내장되어 있는 date 객체 사용 방법 :
// let today = new Date();

// 객체의 프로토타입 , 인스턴스
// 자주사용하는 기능을 하나의 객체로 만든것 : 프로토타입
// 프로토타입을 사용해 만들어낸 객체를 : 인스턴스
// let today = new Date(); => date()객체 = 프로토타입, today = 인스턴스객체

// 자바스크립트 시간은 밀리초 사용 : 1000밀리초 -> 1초 
// 60*1000 밀리초 -> 1분
// 60*60*1000 밀리초 -> 1시간
// 24*60*60*1000 밀리초 -> 1일

//toDateString() : date에서 날짜 부분만 표시할때
//toTimeString() : date에서 시간 부분만 표시할때
//*유의사항 특정 날짜데이터를 사용하고자 할때 월(month)의 값은 1이 아닌 0에서 부터 시작함.

//예제
// let today = new Date();
// let nowMonth = today.getMonth()+1;
// let nowDate =  today.getDate();
// let nowDay = today.getDay();

// document.write("<h1>오늘 날짜 정보</h1>");
// document.write("현재 월 : " + nowMonth + "월<br/>");
// document.write("현재 일 : " + nowDate + "일<br/>");

// let classOpen = new Date("2023-02-28");
// let theMonth = classOpen.getMonth()+1;
// let theDate = classOpen.getDate();

// document.write("<h1>개강일 날짜 정보</h1>");
// document.write("개강 월 : " + theMonth + "월<br/>");
// document.write("개강 일 : " + theDate + "일<br/>");

//예제2
// let today = new Date();
// let nowYear = today.getFullYear();

// let theDate = new Date(nowYear, 11, 31);
// let difDate = theDate.getTime() - today.getTime();

// let result = Math.ceil(difDate / (24 * 60 * 60 * 1000));
// document.write("연말 D-day : " + result + "일 남았습니다")

//기념일 계산
let now = new Date();
let firstDay = new Date("2023-02-28");

let toNow = now.getTime();
let toFisrt = firstDay.getTime();
let passedTime = toNow - toFisrt
let passedDay = Math.round(passedTime / (24 * 60 * 60 * 1000));

document.querySelector("#accent span").innerText = passedDay + "일";


function calcDate(e) {
  let future = toFisrt + e * (24 * 60 * 60 * 1000);
  let someDay = new Date(future);
  let year = someDay.getFullYear();
  let month = someDay.getMonth() + 1;
  let date = someDay.getDate();

  document.querySelector("#date" + e).innerText = year + "년" + month + "월" + date + "일";
}
calcDate(100);
calcDate(200);
calcDate(365);
calcDate(500);