import React from "react";

const Chart = () => {
  return (
    <div>
      <h1>chart</h1>
    </div>
  );
};

export default Chart;
