import { readFilePromise } from "./promise";

readFilePromise("./package.json")
  .then((content: string) => {
    console.log(content);
  })
  .catch((err: any) => console.log("error", err.message));