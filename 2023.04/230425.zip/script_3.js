//함수, 객체, 변수의 심화과정
// 매개변수 인자값, 기본값 설정
// function hello(name, message = "안녕하세요") { //매개변수의 기본값 설정하기
//   console.log(`${name}님, ${message}.`)
// };
// hello("민혜린", "안녕하세요");
// hello("민혜린");

// //전개연산자 (3가지 사용법)
// 1.나머지 매개변수
// 2. 배열합치기
// 3. 배열객체 데이터 복사할떄
// 4. 구조 분해 할당할때

// // function addNum(...numbers) { //매개변수의 갯수에 상관없이 실행된다.
// //   let sum = 0;

// //   for(let el of numbers) {
// //     sum += el;
// //   }
// //   return sum;
// // }
// // console.log(addNum(1,2,3))

// // const animal = ["bird", "cat"];
// // const fruits = ["apple", "banana", "cherry"];

// // //let total = animal.concat(fruits);
// // let total = [...animal, ...fruits];
// // console.log(total)

// const fruits = ["apple", "banana", "cherry"];
// const favorite = fruits;

// favorite[1] = "grape"
// console.log(favorite)
// console.log(fruits)
// //배열객체도 객체이다. 원시유형 자료전달이 아닌 (변수만 가능) 참조주소전달임으로, 원본 데이터까지 변경됨.

// //방지하고 싶다면 전개연산자 사용.(-> mine배열 사용)
// const mine = [...fruits];
// console.log(mine)
// mine[1] = "orange"
// console.log(mine)
// console.log(favorite)

// function fn() {
//   return "result";
// }
// const obj = {
//   [fn()] : "함수 키"
// }
// obj
// {result: '함수 키'}

// function add(a,b){
//   return a+b;
// }
// const obj =  {
//   [`${add(10,20)}`] : "계산식의 키"
// }
// obj
// {30: '계산식의 키'}

// let user = {
//   name : "홍길동"
// }
// user.age = 25;

// function makeUser(name, age) {
//   return {
//     name : name,
//     age : age
//   }
// }

//객체의 Symbol :차별화된 객체의 값을 저장하고자 할 때 사용
// let num1 = Symbol();
// let num2 = Symbol();
// num1==num2
// false

// let id = Symbol();
// const member = {
//   name : "kim",
//   [id] : 12345
// }
// member
// {name: 'kim', Symbol(): 12345}
// member.id = 6789;
// 6789
// member;
// {name: 'kim', id: 6789, Symbol(): 12345}

// let grade = Symbol("grade");
// undefined
// member[grade] = "vip";
// 'vip'
// member;
// {name: 'kim', id: 6789, Symbol(): 12345, Symbol(grade): 'vip'}

//구조 분해 할당 : 주어진 자료의 구조를분해해서 변수에 할당하는 기능
// 꼭그래야하는 이유가 있나요? :
// const fruits = ["사과", "복숭아"];
// undefined
// let apple = fruits[0];
// let peach = fruits[1];
// undefined
// apple
// '사과'
// peach
// '복숭아'

// let [apple, peach] = ["사과", "복숭아"];
// undefined
// apple
// '사과'
// peach
// '복숭아'

// const fruits = ["사과", "복숭아"];
// undefined
// let [apple, peach] = fruits;
// undefined
// apple
// '사과'
// peach
// '복숭아'

// let [spring, ,fall, ] = ["봄", "여름", "가을", "겨울"]
// undefined
// spring
// '봄'
// fall
// '가을'

// //전개연산자도 사용가능
// let [teach, ...student] = ["kim", "lee", "park", "choi"];
// undefined
// teach;
// 'kim'
// student;
// (3) ['lee', 'park', 'choi']

// //변수값 교환방법
// let x = 10;
// let y = 20;
// undefined
// [x, y] = [y, x];
// (2) [20, 10]
// x
// 20
// y
// 10

const student = {
  name : "홍길동",
  score : {
    history : 85,
    science : 94
  },
  friends : ["kim", "lee", "park"]
};

let {
  name,
  score : {
    history,
    science
  },
  friends : [f1, f2, f3]
} = student;
