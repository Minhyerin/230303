$(function() {
  $('#nav_left a, .top a').click(function(e) {
    $.scrollTo(this.hash || 0, 700);
    e.preventDefault();
  });
});