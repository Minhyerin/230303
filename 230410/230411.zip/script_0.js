function calcFunction(price, tax = 0.08) {
  const result = price + price * tax;
  return result; //밖에서 함수를 호출하면 리절트가 결과값으로 반환된다.
} 

const result1 = calcFunction(1000, 0.1);
console.log(result1);


//만약에 함수에 들어갈 수 있는 파라미터 값이 가변 적인 경우(다수인 경우)
function calcSum(...prices) {
  let  result2 = 0;
  for(value of prices) {
    result2 += value;
  }
  return result2;
}
const result3 = calcSum(10,20,30,40);
console.log(result3);



//if 문의 경우 조건문의 내용이 단순한 경우, else(*false) 문장은 생략 가능, 조건문에서 만약 true => if(조건식){중괄호} 중괄호 조차도 생략 가능.
// if(true) {
//   alert('hi');
// }

// const randomNum = Math.random()*10;
// if(randomNum >= 5) alert('randomNum는 5이상!');

// let num = 10;
// if(num >= 5) { 
//   console.log("참입니다.")
// } else {
//   console.log("아닌데")
// }

//switch
// const myFruit = '사과';
// switch (myFruit) {
//   case '사과' :
//     alert('사과입니다');
//     break;
//   case '귤' :
//     alert('귤입니다!');
//     break;
//   default : 
//     alert('기타 과일입니다.')
//     break;
// }

// const myFruit = '사과';
// switch (myFruit) {
//   case '사과' :
//   case '귤' :
//     alert('사과 혹은 귤입니다!');
//     break;
//   default : 
//     alert('기타 과일입니다.')
//     break;
// }

setInterval(function() {
  const now = new Date(); //현재시각 데이터
  const h = now.getHours(); //시
  const m = now.getMinutes(); //분
  const s = now.getSeconds(); //초

  const degH = h * (360 / 12) + m * (360 / 12 / 60);
  const degM = m * (360 / 60); //분침의 각도
  const degS = s * (360 / 60); //초침의 각도

  const elementH = document.querySelector('.lineHour');
  const elementM = document.querySelector('.lineMin');
  const elementS = document.querySelector('.lineSec');

  elementH.style.transform = `rotate(${degH}deg)`;
  elementM.style.transform = `rotate(${degM}deg)`;
  elementS.style.transform = `rotate(${degS}deg)`;
},1000)