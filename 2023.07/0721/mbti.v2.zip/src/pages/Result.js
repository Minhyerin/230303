import React, { useEffect, useState } from "react";
import { styled } from "styled-components";
import "bootstrap/dist/css/bootstrap.min.css";
import { Button } from "react-bootstrap";
import PangImage from "../assets/ggompang.jpeg";
import { useNavigate, useParams, useSearchParams } from "react-router-dom";
import { ResultData } from "../assets/data/resultdata";

const Container = styled.div`
  width: 100%;
  height: 100vh;

  display: flex;
  justify-content: center;
  align-items: center;
  background-color: beige;
`;

const Wrapper = styled.div`
  width: 100%;
  height: 100%;
  border-radius: 30px;
  border: 1px solid #eee;

  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  gap: 30px;
`;
const Header = styled.div`
  font-size: 40px;
  display: flex;
  justify-content: center;
  align-items: center;
`;

const Contents = styled.div`
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  gap: 20px;
`;

const Title = styled.div`
  font-size: 30px;
  color: tomato;
  border-bottom: 2px solid tomato;
`;
const LogoImage = styled.div`
  margin-top: 10px;
`;

const Desc = styled.div`
  font-size: 20px;
  margin-top: 20px;
  margin-bottom: 20px;
  text-align: center;
  width: 600px;
  background-color: #fff;
  padding: 10px;
  color: #333;
  p {
    margin-top: 20px;
    font-size: 16px;
  }
`;

const Result = () => {
  const [searchParams] = useSearchParams();
  const mbti = searchParams.get("mbti");
  const [resultData, setResultData] = useState({});
  useEffect(() => {
    const result = ResultData.find((item) => item.best === mbti);
    setResultData(result);
  }, [mbti]);
  const navigate = useNavigate();
  const handleClickButton = () => {
    navigate("/");
  };

  //const matchDate = ResultData.find((item) => item.best === mbti);
  //console.log(matchDate);

  return (
    <Container>
      <Wrapper>
        <Header>😸예비집사 판별기😸</Header>
        <Contents>
          <Title>결과보기</Title>
          <LogoImage>
            <img
              className="rounded-circle"
              src={resultData.image}
              width={350}
              height={350}
            />
          </LogoImage>
          <Desc>
            예비 집사님과 찰떡궁합인 고양이는 {resultData.best}형{" "}
            {resultData.name}입니다.
            <p>{resultData.desc}</p>
          </Desc>
          <Button variant="danger" onClick={handleClickButton}>
            테스트 다시하기
          </Button>
        </Contents>
      </Wrapper>
    </Container>
  );
};

export default Result;
