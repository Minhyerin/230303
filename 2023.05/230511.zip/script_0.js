
// const student = {
//   name : "철수",
//   school : "그린아카데미",
//   age : parseInt(prompt("철수의 나이는 몇살인가요?"))
// }

// if(student.age === "") {
//   alert("값을 입력하세요");
// } else if (student.age >= 20) {
//   alert("어른입니다.")
// } else if(student.age >= 8) {
//   alert("학생입니다")
// }


// const green = [
//   {
//     name : "철수",
//     age : 17
//   },
//   {
//     name : "영희",
//     age : 22
//   },
//   {
//     name : "도우너",
//     age : 5
//   },
//   {
//     name : "그루트",
//     age : 65
//   },
//   {
//     name : "도비",
//     age : 3
//   }
// ]

// let adult = "";
// let child = "";

// for(let i = 0; i < green.length; i++){
//   if(green[i].age >= 19) {
//     adult += green[i].name + ", ";
//     console.log(green[i].name + "는 성인입니다");
//   } else {
//     child+= green[i].name + ", ";
//     console.log(green[i].name + "는 미성년입니다")
//   }
// }

// console.log("성인인 멤버는 " + adult + "입니다.");
// console.log("미성년 멤버는 " + child + "입니다.");


// const fruit = [
//   {lank : 1, name : "레드향"},
//   {lank : 2, name : "샤인머스켓"},
//   {lank : 3, name : "산청딸기"},
//   {lank : 4, name : "한라봉"},
//   {lank : 5, name : "사과"},
//   {lank : 6, name : "애플망고"},
//   {lank : 7, name : "딸기"},
//   {lank : 8, name : "천혜향"},
//   {lank : 9, name : "과일선물세트"},
//   {lank : 10, name : "귤"}
// ]

// for(let i = 0; i < fruit.length; i++) {
//   console.log(fruit[i].lank + "위 " + fruit[i].name);
// }


// const number = Math.random();
// const token = Math.floor(number * 1000000);
// const paddentoken = String(token).padStart(6, "0");
// console.log("휴대폰 인증번호 : " + paddentoken);

function greeting() {
  document.querySelector("#target").innerText = "world"
}