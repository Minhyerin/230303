import React from "react";
import { ITodo, todoState } from "./Atoms";
import { useSetRecoilState } from "recoil";

// const food = ["pizza", "mango", "kimchi", "kimbab"];
// const target = 1;
// const front = ["pizza"];
// const back = ["kimchi", "kimbab"];

// const final = [...front, "hamberger", ...back];
// const final2 = [
//   ...food.slice(0, target),
//   "hamberger",
//   ...food.slice(target + 1),
// ];
// console.log(final2);

const Todo = ({ id, text, category }: ITodo) => {
  const setTodos = useSetRecoilState(todoState);
  const onClick = (event: React.MouseEvent<HTMLButtonElement>) => {
    const {
      currentTarget: { name },
    } = event;
    setTodos((oldTodos) => {
      const targetIndex = oldTodos.findIndex((todo) => todo.id == id);
      const oldTodo = oldTodos[targetIndex];
      const newTodo = { id, text, category: name as any };
      return [
        ...oldTodos.slice(0, targetIndex),
        newTodo,
        ...oldTodos.slice(targetIndex + 1),
      ];
    });
  };
  return (
    <li>
      <span>{text}</span>
      {category !== "DOING" && (
        <button name="DOING" onClick={onClick}>
          Doing
        </button>
      )}
      {category !== "TO_DO" && (
        <button name="TO_DO" onClick={onClick}>
          To do
        </button>
      )}
      {category !== "DONE" && (
        <button name="DONE" onClick={onClick}>
          Done
        </button>
      )}
    </li>
  );
};

export default Todo;
