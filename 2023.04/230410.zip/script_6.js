$(function() {
  $(".btn2").hide();

  $(".btn1").on("click", function() {
    $(".box").slideUp(1000, "linear", function() {
      $(".btn1").hide();
      $(".btn2").show();
    });
  });

  $(".bnt2").on("click", function() {
    $(".box").fadeIn(1000, "swing", function() {
      $(".btn2").hide();
      $(".btn1").show();
    });
  });

    $(".btn3").on("click", function() {
      $(".box").slideToggle(1000, "linear");
    });

    $(".btn4").on("click", function() {
      $(".box").fadeTo("fast", 0.3);
    });
    $(".btn5").on("click", function() {
      $(".box").fadeTo("fast", 1);
    });
});

//애니메이션(소요시간, 가속정도, 콜백함수)