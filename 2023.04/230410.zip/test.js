$(function() {
  $(".btn1").on("click", function(e) {
    e.preventDefault();
    $(".txt1")
    .css({
      "background-color" : "yellow"
    });
  })

  $(".btn2").on("click", function() {
    $(".btn2").attr("href", "https://www.naver.com");
    $(".txt2")
    .css({
      "background-color" : "aqua"
    });
  });

  $(".btn3").on("dblclick", function() {
    $(".txt3")
    .css({
      "background-color" : "green"
    });
  });

  $(".btns button").on("click", zoomInOut);
  let fontst = 14;
  function zoomInOut() {
    if($(this).hasClass("zoomOutBtn")) {
      if(fontst <= 8)
        return false;
        fontst--;
    } else if($(this).hasClass("zoomInBtn")) {
      if(fontst >= 20)
        return false;
        fontst++;
    } else {
      fontst = 14;
    }
    $("body")
    .css({
      fontSize : fontst + "px"
    });
    $(".fontSize").text(fontst + "px");
  };
});
