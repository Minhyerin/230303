$(function() {
  $(document).on("keydown", keyEventFnc);
  function keyEventFnc(e) {
    let direct = "";

    switch(e.keyCode) {
      case 37 : direct = "Left";
      break;
      case 38 : direct = "top";
      break;
      case 39 : direct = "right";
      break;
      case 40 :  direct = "bottom";
    };
    if(direct) $("#user_id").val(direct);
  };

  $(".menuWrap_1 a").on("click", function(e) {
    e.preventDefault();

    $(".menuWrap_1 a")
    .css({
      "background-color" : "#fff"
    });

    $(this)
    .css({
      "background-color" : "#ff0"
    });
  })

  $(".menuWrap_2 a").on("click", function(e) {
    e.preventDefault();

    $(".menuWrap_2 a")
    .css({
      "background-color" : "#fff"
    });

    let idx = $(".menuWrap_2 a").index(this);
    $(".menuWrap_2 a").eq(idx)
    .css({
      "background-color" : "#0ff"
    });

    $(".idxNum").text(idx);
  });
});