const origin = document.querySelector("#origin");
const result = document.querySelector("#result");

let numbers = [2, 4, 6, 8, 10];

show(origin, numbers);

function show(area, numbers){
  let t = "<table><tr>";
  for(let i = 0; i < numbers.length; i++){
    t += "<td>" + numbers[i] + "</td>"
  }
  t += "</tr></table>"
  area.innerHTML = t;
}

let sum = 0;
for(let i = 0; i < numbers.length; i++){
  sum += numbers[i];
};
numbers.push(sum);
show(result, numbers)