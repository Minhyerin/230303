import React from "react";

const Price = () => {
  return (
    <div>
      <h1>price</h1>
    </div>
  );
};

export default Price;
