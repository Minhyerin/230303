$(function() {
  $('#fullpage').fullpage({
    slidesNavigation: true,
    responsiveWidth: 1024,
    autoScrolling: true
  });

  $('.work-images').slick({
    dots: false,
    infinite: true,
    speed: 300,
    slidesToShow: 1,
    slidesToScroll: 1
  });

})