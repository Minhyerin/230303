let info = navigator.userAgent.toLowerCase();
let osImg = null;

if(info.indexOf('windows') >= 0) {
  osImg = 'windows.png';
} else if(info.indexOf('macintosh') > 0) {
  osImg = 'macintosh.png';
} else if(info.indexOf('iphone') > 0) {
  osImg = 'iphone,png';
} else if(info.indexOf('android') > 0) {
  osImg = 'android.png';
}

document.write("<img src=\"/img/"+ osImg +"\">", "<br/>");
let src = screen;
let src_w = src.width;
let src_h = src.height;

document.write("모니터 해상도 너비 : " + src_w + "px", "<br/>");
document.write("모니터 해상도 높이 : " + src_h + "px", "<br/>");