// createElement( ) : 요소 노드 만들기
// createTextnode( ) :텍스트 노드만들기
// appendChild( ) : 부모요소에 자식요소 연결하기

// createAttribute( ) :  속성 노드 만들기
// setAttributeNode( ) :  속성 노드 연결하기
/*
let newImg = document.createElement("img");
undefined
let srcNode = document.createAttribute("src");
undefined
srcNode.value = "/img/iu.jpg";
'/img/iu.jpg'
newImg.setAttributeNode(srcNode);
null
document.body.appendChild(newImg);
<img src=​"/​img/​iu.jpg">​
*/

//(오전,오후)시간에 따라 바뀌는 이미지
// 1. 시간(오전/오후)에 대한 개념 정의
// 2. 시간 변화에 따라서 출력해줘야하는 이미지가 어떤것인지에 대한 정의 > 시간변화 정의 -> 이미지정의
// 3. 이미지를 출력할 공간에 대한 정의

const container = document.querySelector("#container"); //3
const today = new Date(); //현 시점의 날짜, 시간
const hrs = today.getHours(); // 현 시점의 시간만 저장

let newImgs = document.createElement("img"); //시간의 따라 바뀌어야하기 때문에 변수 키워드 let 선언
newImgs.src = (hrs < 12) ? "/img/morning.jpg" : "/img/afternoon.jpg";

container.appendChild(newImgs);

