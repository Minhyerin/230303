//프로미스 객체
// let likePizza = true;
// const pizza = new Promise((resolve, reject) => {
//   if(likePizza) {
//     resolve("피자를 주문합니다.")
//   } else {
//     reject("피자를 주문하지 않습니다.")
//   }
// });

// pizza
//   .then(
//     (result) => console.log(result)
//     )
//   .catch(
//     (err)=>console.log(err)
//     ).finally(
//       () => console.log("완료")
//     );

//예제
let coffee = prompt("어떤 커피를 주문하시겠습니까?", "아메리카노");
const order = new Promise((resolve, reject) => {
  if(coffee != null && coffee !=""){
    document.querySelector("#start").innerText = `${coffee} 주문접수`;
    setTimeout(() => {
      resolve(coffee);
    }, 3000)
  } else {
    reject("커피를 주문하지 않았습니다.")
  }
});

function display(coffee) {
  document.querySelector("#end").innerText = `${coffee} 준비완료 ☕`;
  document.querySelector("#end").classList.add("active");
  document.querySelector("#start").classList.add("done");
}

function showErr(err) {
  document.querySelector("#start").innerText = err;
}

order
  .then(display)
  .catch(showErr);
