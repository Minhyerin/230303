let newP = document.createElement("p");
//새로운 노드요소를 만든다. 즉 p 태그를 만든다.
let newText = document.createTextNode("주문이 완료 되었습니다!!");
//요소 노드 안에 들어가는 값
let attr = document.createAttribute("class");
//class라는 속성을 만든다.

newP.appendChild(newText);
//p 의 자손요소로 텍스트 노드를 
document.body.appendChild(newP);
//body속성 안에 newP를 자식요소로 들어가게.
attr.value = "accent";
//class 속성을 생성했는데, 그 속성의 값을 지정 : class="accent"
newP.setAttributeNode(attr);
//위에서 지정한 속성, 속성값을 p태그에 연결해준다.