let userNum = prompt("당신의 번호는?", "");
let result = userNum.substring(0, userNum.length-4);

document.write(result, "****", "<br/>");



let img= "bnt_out.jpg";
let result2 = img.replace("out.jpg", "over.png");
document.write(result2, "<br/>");


let menu = ["김밥", "라면", "떡볶이", "파스타"];
let menuNum = Math.floor(Math.random()* menu.length);
let result1 = menu[menuNum];

document.write(result1);