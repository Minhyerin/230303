const today = new Date();
const firstDay = new Date("2023-02-28");
const result = document.querySelector("#result");

let passedTime = today.getTime() - firstDay.getTime();
let passedDay = Math.round(passedTime / (24 * 60 * 60 * 1000));

result.innerText = passedDay;