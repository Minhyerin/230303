/* let menu = ["김치찌개", "칼국수", "햄버거", "김밥", "파스타"];
let menuNum = Math.floor(Math.random() * menu.length);
let result = menu[menuNum];

document.write(result); */

const form = document.querySelector('form');
const input = document.querySelector('input');
const ul = document.querySelector('ul');

form.addEventListener('submit', function(event) {
  event.preventDefault();

  if(input.value !== '') {
    const li = document.createElement('li');
    li.innerText = input.value;
    ul.appendChild(li);
    input.value = '';
  };
});