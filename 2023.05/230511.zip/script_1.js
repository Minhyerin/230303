// ========== 1번 
// 최소값구하기

// const num1 = parseInt(prompt("첫번째 숫자를 입력하세요"));
// const num2 = parseInt(prompt("두번째 숫자를 입력하세요"));
// const num3 = parseInt(prompt("세번째 숫자를 입력하세요"));

// function solution(a,b,c) {
//   if(a < b) {
//     answer = a;
//   } else {
//     answer = b;
//   }
  
//   if(c < answer) {
//     answer = c;
//   }
//   return answer
// }

// console.log(solution(num1,num2,num3));


// ========== 2번
// 삼각형을 만들 수 있다면 YES, 만들 수 없다면  NO

// const num1 = parseInt(prompt("첫번째 숫자를 입력하세요"));
// const num2 = parseInt(prompt("두번째 숫자를 입력하세요"));
// const num3 = parseInt(prompt("세번째 숫자를 입력하세요"));
// //정삼각형, 이등변삼각형, 직각삼각형, 일반삼각형
// //1개의 변 길이가 나머지 2개의 변 길이의 합보다 크면 삼각형이 될 수 없다

// function solution(a, b, c) {
//   let answer = "YES";
//   let max  = "";
//   let total = a + b + c;

//   if(a > b) {
//     max = a;
//   } else {
//     max = b;
//   }

//   if(c > max) {
//     max = c;
//   }

//   if(total - max <=  max) {
//     answer = "NO";
//   }
//   return answer;
// }

// console.log(solution(num1,num2,num3));


// ========== 3번
// 사용자에게 빵을 몇개 줄 수 있는지 물어보고, 16명이 각각 몇개씩 나눠먹을수 있는지

// const num1 = parseInt(prompt("빵을 몇개 줄 수 있나요?"));
// const num2 = 16

// // function solution(a, b) {
// //   let c = a / b;
  
// //   return c.toFixed(1);
// // }
// // console.log(solution(num1, num2) + "개");

// function solution(e) {
//   if( e < 16) {
//     console.log("장난하냐");
//   } else {
//     let answer = Math.floor(e / num2);
//     return answer;
//   } 
// }
// console.log(solution(num1));



// ========== 4번
// 사용자로부터 특정 숫자를 받고, 그 숫자만큼 더하기를 한 결과출력
// ex.100 =>  1 + 2 + ... + 100

// const num1 = parseInt(prompt("몇까지 더할까요"));
// function solution(e) {
//   let answer = 0;
//   for(let i = 0; i <= e; i++){
//     answer += i;
//   }
//   return answer;
// }
// console.log(solution(num1));


// ========== 5번
// 배열 [5, 7, 1, 3, 2, 9, 11] 에서 최소값을 찾아 콘솔 창에 출력해주세요

// const arr = [5, 7, 1, 3, 2, 9, 11];
// function solution(e) {
//   let answer = "";
//   let max = Number.MAX_SAFE_INTEGER;

//   for(let i = 0; i < arr.length; i++){
//     if(arr[i] < max) {
//       max = arr[i];
//     }

//     answer = max;
//   }
//   return answer;
// }
// console.log(solution(arr));



// ========== 6번
// 배열 [12, 77, 38, 41, 53, 92, 85] 에서 홀수 값만 더하고 결과값 & 이중 가장 작은 수만 콘솔 창에 출력

const arr = [12, 77, 38, 41, 53, 92, 85];

function solution(e) {
  let answer = [];
  let sum = 0;
  let min = Number.MAX_SAFE_INTEGER;

  for(let i = 0; i < arr.length; i++){
    if(arr[i] % 2 === 1) {
      sum += arr[i];
      if(arr[i] < min) {
        min = arr[i];
      }
    }
  }
  answer.push(sum);
  answer.push(min);
  return answer;
}

console.log(solution(arr));