// 사용자로부터 강아지 이름을 받고,
// 안내문으로 강아지 이름이 담겨있는 문장을 띄워보기.

// Pet class를 상속받는 Cat class 를 신규로 만들기
// 사용자로부터 고양이 이름을 받아서 안내문에 고양이 이름 : 품종 : 색깔을 출력해주세요.

let ques = prompt("강아지 이름을 알려주세요");

class Pet {
  constructor(name, color) {
    this.name = name;
    this.color = color;
  }
  run() {
    alert(`${this.name} is running`)
    location.reload();
  }
}
const dog = new Pet(ques, "brown");
dog.run();


let ques1 = prompt("고양이 이름을 알려주세요");

class Cat extends Pet {
  constructor(name,color,breed) {
    super(name,color);
    this.breed = breed;
  }
  catIs() {
    alert(`고양이이름은 : ${this.name}, 색깔은 : ${this.color}, 품종은 : ${this.breed} 입니다.`);
    location.reload();
  }
}

const cat1 = new Cat(ques1, "white", "코리안숏헤어");
cat1.catIs();