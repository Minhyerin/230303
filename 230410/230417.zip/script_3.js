//자바스크립트 이벤트 전파

// 1.이벤트 버블링
// => 특정요소에서 이벤트가 발생했을때 그 이벤트가 해당요소 뿐만 아니라, 해당요소의 부모요소, 부모요소의 부모요소에도 똑같이 발생한 것으로 간주하는 것.
//currentTarget:  현재 클릭된 요소의 상위요소에 있는 애들 중에 이벤트 리스너가 달린 애들 =  선택자의 상위요소듷 무슨말이야
// target : 이벤트가 발생한 

const elements = document.querySelectorAll("*");
for(let el of elements) {
  el.addEventListener("click", e => {
    console.log(`e.target: ${e.target.tagName}, e.currentTarget: ${e.currentTarget.tagName}`)
  });
};

// 2. 이벤트 캡처링