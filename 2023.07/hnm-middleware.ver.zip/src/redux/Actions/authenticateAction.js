function login(id, padssword) {
  return (dispatch, getState) => {
    dispatch({ type: "LOGIN_SUCCESS", payload: { id, padssword } });
  };
}

export const authenticateAction = { login };
