// 인풋 박스안에 들어오는 값
// 버튼에 대한 정의
//출력되는 공간
// 출력될 컨텐츠  : 오늘 현재 날짜 , 오늘까지 흐른 날, 시간 

/*
const birthYear = document.querySelector("#year");
const birthMonth = document.querySelector("#month");
const birthDate = document.querySelector("#date");


let birth = new Date(birthYear.value, birthMonth.value, birthDate.value);

const btn = document.querySelector("#btn");

const current = document.querySelector("#current");
const days = document.querySelector("#days");

let now = new Date();

let todayY = now.getFullYear();
let todayM = now.getMonth() + 1;
let todayD = now.getDate();

let hour = now.getHours();
let min = now.getMinutes();


btn.addEventListener("click", (e) => {
  e.preventDefault();
  current.innerText = `${todayY}년 ${todayM}월 ${todayD}일 ${hour}시 ${min}분 현재`;

  let passedDay = (birth.getTime - now.getTime) * (24*60*60*1000);
  days.innerText = `날짜로는 ${passedDay} 일이 흐르고 `
})
*/



// 계산이란 버튼에 대한 정의
// 사용자로부터 값을 입력받고 저장하는 공간에 대한 정의
// 원하는 값을 출력하는 공간에 대한 정의
// 출력할 값의 대한 계산
const btn = document.querySelector("#btn");

const birthYear = document.querySelector("#year");
const birthMonth = document.querySelector("#month");
const birthDate = document.querySelector("#date");

const current = document.querySelector("#current");
const resultDays = document.querySelector("#days");
const resultHours = document.querySelector("#hours");
const resultYears = document.querySelector("#years");

const today = new Date();
current.innerText = `${today.getFullYear()}년 ${today.getMonth()+1}월 ${today.getDate()}일 ${today.getHours()}시 ${today.getMinutes()}분 현재`;

btn.addEventListener("click", (e) => {
  e.preventDefault();
  const birthDay = new Date(birthYear.value, birthMonth.value - 1, birthDate.value);

  let passed = today.getTime() - birthDay.getTime();
  let passedYears = Math.floor(passed / (1000 * 60 * 60 * 24 * 365));
  let passedDays = Math.floor(passed / (1000* 60 * 60 * 24));
  let passedHours = Math.floor(passed / (1000* 60 * 60));

  resultDays.innerText = `날짜로는 ${passedDays} 일이 흘렀습니다.`;
  resultHours.innerText = `시간으로는 ${passedHours} 시간이 흘렀습니다.`
  resultYears.innerText = `년으로는 ${passedYears} 년이 흘렀습니다.`;

  birthYear.value = "";
  birthMonth.value = "";
  birthDate.value = "";
});