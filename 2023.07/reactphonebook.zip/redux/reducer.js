let initialState = {
  contact: [],
  keyword: "",
};

function reducer(state = initialState, action) {
  const { type, payload } = action;
  switch (type) {
    case "ADD_CONTACT":
      // return {
      //   ...state,
      //   contactList: [
      //     ...state.contactList,
      //     { name: payload.name, phone: payload.phone },
      //   ],
      // };
      state.contact.push({
        name: payload.name,
        phone: payload.phone,
      });
      break;
    case "SEARCH_BY_NAME":
      state.keyword = payload.keyword;
      break;
  }
  return { ...state };
}

export default reducer;
