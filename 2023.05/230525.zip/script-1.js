// 1.사용자로부터 id/pw를 받아서, 일치하지 않을 경우와 일치하는 경우 알림창으로 메세지 출력
// const id = "green";
// const pw = 1234;

// let userId = prompt("아이디를 입력하세요");
// if(userId == id) {
//   let userPw = parseInt(prompt("비밀번호를 입력하세요"));
//   if(userPw == pw) {
//     alert(`${id}님, 반갑습니다.`);
//   } else {
//     alert("비밀번호가 일지 하지 않습니다. 다시 로그인해주세요");
//     location.reload();
//   }
// } else {
//   alert("아이디가 일치 하지 않습니다. 다시 입력하세요");
//   location.reload();
// }


//버튼 클릭하면 테이블에 출력하기
// const userName = document.querySelector("#userName");
// const userMajor =  document.querySelector("#userMajor");
// const btn = document.querySelector("button");


// btn.addEventListener("click", (e) => {
//   e.preventDefault();
//   let tr = document.createElement("tr");
//   let td1 = document.createElement("td");
//   let td2 = document.createElement("td");
//   td1.innerText = userName.value;
//   td2.innerText = userMajor.value;
//   tr.appendChild(td1);
//   tr.appendChild(td2);
//   document.querySelector("table").appendChild(tr);
//   userName.value = "";
//   userMajor.value = "";
// });


let numbers = [2, 4, 6, 8, 10];
const origin = document.querySelector(".origin");
const result = document.querySelector(".result");

function showArr(a,b) {
  let str = "<table><tr>";
  for(let i = 0; i < b.length; i++) {
    str += "<td>" + b[i] + "</td>"
  }
  str += "</tr></table>";
  a.innerHTML = str;
}
showArr(origin, numbers);

let sum = 0;
for(let i = 0; i < numbers.length; i++){
  sum += numbers[i];
}
numbers.push(sum);
showArr(result, numbers);