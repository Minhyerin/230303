//핸드폰 번호 입력시 포커스
function changePhone1() {
  const p1 = document.querySelector("#p1").value;
  if(p1.length === 3) {
    document.querySelector("#p2").focus();
  }
}
function changePhone2() {
  const p2 = document.querySelector("#p2").value;
  if(p2.length === 4) {
    document.querySelector("#p3").focus();
  }
}
function changePhone3() {
  const p1 = document.querySelector("#p1").value;
  const p2 = document.querySelector("#p2").value;
  const p3 = document.querySelector("#p3").value;
  if(p1.length === 3 && p2.length === 4 && p3.length === 4) {
    document.querySelector("#send").removeAttribute("disabled");
    document.querySelector("#send").style = "color: #0068ff; background-color : #fff; cursor: pointer;"
  }
}

//인증번호 전송
function tokenstart() {
  const token = String(Math.floor(Math.random() * 1000000)).padStart(6, "0");
  document.querySelector("#result").innerHTML= token;
  document.querySelector("#send").style = "color : #000"
  document.querySelector("#send").setAttribute("disabled", "true");

  document.querySelector("#done").style = "background-color : #0068ff; color :  #fff; cursor : pointer;"
  document.querySelector("#done").removeAttribute("disabled");

  getTokenTimer();
}
//인증번호 입력 시간타이머
let interval;
function getTokenTimer() {
  let timer = 5;
  interval = setInterval(() => {
    if(timer >= 0) {
      const minutes =  Math.floor(timer / 60);
      const seconds = String(timer % 60).padStart(2, "0");
      document.querySelector("#time").innerText = minutes + ":" + seconds;
      timer = timer - 1;
    } else {
      document.querySelector("#result").innerText = "000000"
      document.querySelector("#time").innerText = "3:00"
      document.querySelector("#send").style = "";
      document.querySelector("#done").style = "";
      document.querySelector("#done").setAttribute("disabled", "true");
      document.querySelector("#done").innerText = "인증시간 초과"
      clearInterval(interval);
    }
  } ,1000)
}

//인증완료 버튼 클릭시 알림창
function getTokenTimerConfirm() {
  clearInterval(interval);
  document.querySelector("#done").style = "background-color : #fff";
  document.querySelector("#done").setAttribute("disabled", "true");
  document.querySelector("#done").innerText = "인증 완료";
  alert("인증이 완료되었습니다.");

  document.querySelector(".signup-btn").removeAttribute("disabled")
  document.querySelector(".signup-btn").style = "background-color : #fff; color : #0068ff; border : 1px solid #0068ff; cursor : pointer";
}

//가입하기 버튼 클릭시 검증하기
function signUp() {
  const email = document.querySelector("#email").value;
  const name = document.querySelector("#name").value;
  const pw1 = document.querySelector("#pw1").value;
  const pw2 = document.querySelector("#pw2").value;
  const location = document.querySelector("#location").value;
  const genderFemale = document.querySelector("#female").checked;
  const genderMale = document.querySelector("#male").checked;

  let isValid = true;
  if(email.includes("@") === false) {
    document.querySelector("#error_email").innerText = "이메일이 올바르지 않습니다."
    isValid = false;
  } else {
    document.querySelector("#error_email").innerText = "";
  }
  
  if(name === "") {
    document.querySelector("#error_name").innerText = "이름이 올바르지 않습니다."
    isValid = false;
  } else {
    document.querySelector("#error_name").innerText = "";
  }

  if(pw1 === "") {
    document.querySelector("#error_pw1").innerText = "비밀번호를 입력해주세요."
    isValid = false;
  } else {
    document.querySelector("#error_pw1").innerText = "";
  }

  if(pw2 === "") {
    document.querySelector("#error_pw1").innerText = "비밀번호가 일치하지 않습니다."
    document.querySelector("#error_pw2").innerText = "비밀번호가 일치하지 않습니다."
    isValid = false;
  }

  if(location !=="서울" && location !=="경기" && location !=="인천") {
    document.querySelector("#error_location").innerText = "지역을 선택해주세요."
    isValid = false;
  } else {
    document.querySelector("#error_location").innerText = "";
  }

  if(genderFemale == false && genderMale == false) {
    document.querySelector("#error_gender").innerText = "성별을 선택해주세요."
    isValid = false;
  } else {
    document.querySelector("#error_gender").innerText = "";
  }

  if(isValid === true) {
    alert("회원가입을 축하합니다.")
  }
}

/*
// 핸드폰 번호 입력
const changeFocus1 = () => {
  let p1 = document.querySelector("#p1").value;
  if(p1.length === 3){
    document.querySelector("#p2").focus();
  }
}
const changeFocus2 = () => {
  let p2 = document.querySelector("#p2").value;
  if(p2.length === 4){
    document.querySelector("#p3").focus();
  }
}
const changeFocus3 = function() {
  let p1 = document.querySelector("#p1").value;
  let p2 = document.querySelector("#p2").value;
  let p3 = document.querySelector("#p3").value;

  if(p1 && p2 && p3) { 
    document.querySelector("#send").disabled = false;
    send.style = "border : 1px solid #0068ff; color : #0068ff;"
  } else {
    document.querySelector("#send").disabled = true;
  }

  if(p3.length === 4) {
    document.querySelector("#send").focus();
  }
}

//인증번호 전송 클릭시, 인증번호 표시 및 타이머작동
const result = document.querySelector("#result");
//const button = document.querySelector("button");
const timer = document.querySelector("#timer");
const done = document.querySelector("#done");

let isStarted = false;
function tokenstart() {
  if(isStarted === false) {
    // timer가 작동중이지 않을때
    isStarted = true;

    const token = String(Math.floor(Math.random() * 1000000)).padStart(6, "0");
    result.innerHTML = token;
  
    let time = 30;
    setInterval(function timeclock() {
    if(time >= 0) {
      done.disabled = false;
      done.style = "border : 1px solid #0068ff; color : #0068ff;"
      let min = Math.floor(time / 60);
      let sec = String(time % 60).padStart(2, "0");
      timer.innerHTML = `${min}:${sec}`;
      time = time - 1;

    } else {
      done.disabled = true;
      done.innerText = "인증시간 초과";
      isStarted = false;
    }
  }, 1000)
  } else {
    //timer 작동중일때
  }
}
//인증완료 버튼 클릭시, 알림창
done.addEventListener("click", () => {
  alert("인증이 완료되었습니다.");
});

// 모든 정보 기입시 가입하기 버튼 활성화
const email = document.querySelector("#email");
const name = document.querySelector("#name").value;
const pw1 = document.querySelector("#pw1").value;
const pw2 = document.querySelector("#pw2").value;
const signUpBtn =  document.querySelector(".signup-bnt");
if(email && name && pw1 && pw2 && p1 && p2 && p3) {
  signUpBtn.disabled = "false"; 
} else {
  signUpBtn.disabled = "true"; 
}
*/