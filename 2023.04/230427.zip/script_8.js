// function whatsYourFavorite() {
//   let fav = "javascript";
//   return new Promise((resolve, reject) => resolve(fav));
// }

// function displaySubject(subject) {
//   return new Promise((resolve, reject) => resolve(`Hello, ${subject}`));
// }

// whatsYourFavorite()
//   .then(displaySubject)
//   .then(console.log)

async function whatsYourFavorite() {
  let fav = "javascript";
  return fav;
}

async function displaySubject(subject) {
  return `Hello, ${subject}`;
}

// whatsYourFavorite()
//   .then(displaySubject)
//   .then(console.log)
async function init() {
  const response = await whatsYourFavorite();
  const result = await displaySubject(response);
  console.log(result)
};
init();

// whatsYourFavorite() 함수 실행이 끝날때까지 기다린 후에 response값을 저장
// response값을 사용해서 displaySubject()함수를 실행하고 결과값을 result에 저장