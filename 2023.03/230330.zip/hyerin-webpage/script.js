$('#fullpage').fullpage({
  slidesNavigation: true,
  responsiveWidth: 1024,
  autoScrolling: true
});