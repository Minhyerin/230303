// 텍스트 input 태그 필드에 입력한 값 가져오기
//  선택요소.value
// 만약, id 값과 class값이 없다면? name이라는 속성값을 통해 가져올수 있다.

// document.order.product.value; //태그의 네임값으로 가져오기
// '짜장밥'

// forms 활용하여 form 태그를 배열객체로 가져오기.
//document.forms[0]
//document.forms[0].elements //elements 는 하위요소들
//document.forms[0].elements[0]

//document.querySelector("#option").options; 각각의배열객체로 데이터를 가져올수있다.
/*
const selectMenu = document.querySelector("#option");

function displaySelect () {
  let selectedText = selectMenu.options[selectMenu.selectedIndex].innerText;
  alert(`[${selectedText}]를 선택했습니다.`);
}
selectMenu.onchange = displaySelect;
*/

// input 태그 역시 배열객체로 가져올수 있다.
//document.order.delivery;
//RadioNodeList(3) [input, input, input, value: 'before'] ==> 벨류값은 선택된값

// document.order.mailing;
// RadioNodeList(3) [input#mailing, input#mailing, input#mailing, value: '']
// document.order.mailing[1].value;
// 'fashion'
// document.querySelector("input[name= 'mailing']:checked");
// <input type=​"checkbox" id=​"mailing" value=​"fruit" name=​"mailing">​
// document.querySelectorAll("input[name= 'mailing']:checked");
// NodeList(2) [input#mailing, input#mailing]

const btn = document.querySelector("#view");
btn.onclick = () => {
  document.querySelector("#detail").classList.toggle("hidden");
}