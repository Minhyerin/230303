function showPrice() {
  let originPrice = document.querySelector('#oPrice').value;
  let rate = document.querySelector('#rate').value;
  let savePrice = originPrice * (rate/100);
  let resultPrice = originPrice - savePrice;

  document.querySelector('#showResult').innerHTML = "상품의 원래 가격은 " + originPrice + "원 이고, 할인율은 " + rate + "% 입니다. " + savePrice + "원을 절약한 " + resultPrice + "원에 구매할 수 있습니다.";
}