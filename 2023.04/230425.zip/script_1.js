// 1.출력공간에 대한 정의
// - 원래배열 출력
// - 모든값을 더한 배열 출력
// 2.주어진 배열을 더하는 연산 계산식 정의
// 3.출력방식에대한 정의 - table 형식

const origin = document.querySelector("#origin");
const result = document.querySelector("#result");

let numbers = [2, 4, 6, 8, 10];

showArray(origin, numbers);

function showArray(area, numbers) {
  let t = "<table><tr>";
  for(let i = 0; i < numbers.length; i++){
    t += "<td>" + numbers[i] +"</td>"
  }
  t += "</tr></table>"
  area.innerHTML = t;
}

let sum = 0;
for(let i = 0; i < numbers.length; i++){
  sum += numbers[i];
}
numbers.push(sum);

showArray(result, numbers);