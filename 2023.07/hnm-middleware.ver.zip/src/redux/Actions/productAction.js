function getProduct(keyword) {
  return async (dispatch, getState) => {
    let url = `https://my-json-server.typicode.com/legobitna/hnm-react-router/products?q=${keyword}`;
    let response = await fetch(url);
    let data = await response.json();
    dispatch({ type: "GET_PRODUCT_SUCCESS", payload: { data } });
    //setProducts(data);
  };
}

export const productAction = { getProduct };
