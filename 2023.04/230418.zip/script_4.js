// 1. 제목, 저자에 대한 데이터 공간 및 정의
// 2. 취소하기, 저장하기 버튼에 대한 정의
// 3. 삭제하기 버튼에 대한 정의
// 4. 입력된 데이터가 출력될 공간에 대한 정의

let title = document.querySelector("#title");
let author = document.querySelector("#author");
const save = document.querySelector("#save");
const bookList = document.querySelector("#booklist");

save.addEventListener("click", (e) => {
  e.preventDefault(); //기본 값 삭제

  const item = document.createElement("li");
  item.innerHTML = `${title.value} -  ${author.value} 
  <span class="delButton">삭제</span>`;
  bookList.appendChild(item);

  title.value = "";
  author.value = "";  //저장하기 후에 인풋박스에 값 지우기

  
  const delButtons = document.querySelectorAll(".delButton");
  //delbutton 은 여러개이기 때문에
  for(let delButton of delButtons) { 
    delButton.addEventListener("click", removeItem);
  };//여러 값중에 어떤 삭제버튼을 누를지 모르기때문에
});

function removeItem() {
  let list = this.parentNode;
  list.parentNode.removeChild(list);
};