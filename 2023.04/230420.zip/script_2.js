// 바뀌어야 할 배경이미지들에 대한 정의 
// 이미지가 랜덤으로 나타나야 하는 
// 배열객체를 사용하지 않고도 만들 수 있당

// const bgImgs = ["bg-1.jpg","bg-2.jpg","bg-3.jpg","bg-4.jpg","bg-5.jpg"];
// const bgIndex = Math.floor(Math.random() * bgImgs.length);
// function changeBg() {
//   document.body.style.backgroundImage = `url(img/${bgImgs[bgIndex]})`;
// } //url 값 잘못입력해서 안나왔음..ㅈㅔ대로만 했어두 나오는데;;..
// changeBg();

//출력할 공간에 대한 정의
// 출력할 컨텐츠에 대한 정의

const changeBg = () => {
  const bgCount = 5;
  let randomNum = Math.ceil(Math.random() * bgCount);
  document.body.style.backgroundImage = `url(img/bg-${randomNum}.jpg)`
}

document.onload = changeBg();