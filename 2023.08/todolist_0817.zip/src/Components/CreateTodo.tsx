import React from "react";
import { useForm } from "react-hook-form";
import { useSetRecoilState } from "recoil";
import { ITodo, todoState } from "./Atoms";

interface IForm {
  todo: string;
}

const CreateTodo = () => {
  const setTodos = useSetRecoilState(todoState);
  const { register, handleSubmit, setValue } = useForm<IForm>();
  const handleValid = ({ todo }: IForm) => {
    setTodos((oldTodos) => [
      { id: Date.now(), text: todo, category: "TO_DO" },
      ...oldTodos,
    ]);
    setValue("todo", "");
  };
  return (
    <form onSubmit={handleSubmit(handleValid)}>
      <input
        {...register("todo", { required: "Please write a Todo" })}
        placeholder="write a todo"
      />
      <button>add</button>
    </form>
  );
};

export default CreateTodo;
