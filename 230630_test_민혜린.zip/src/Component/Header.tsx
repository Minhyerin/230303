import React from "react";
import { styled } from "styled-components";

const HeaderTilte = styled.div`
  color: rgb(0, 0, 220);
  font-size: 22px;
  font-weight: bold;
  margin-bottom: 30px;
`;

const Header = () => {
  return (
    <HeaderTilte>
      회원가입을 위해
      <br />
      정보를 입력해 주세요
    </HeaderTilte>
  );
};

export default Header;
