// anime({
//   targets : "ul.menu li",
//   translateX : 250,
//   easing : "linear",
//   loop : true,
//   direction : "alternate",
//   delay : function(el, i, l) {
//     console.log(el, i, l);
//   }
//   // endDelay : anime.stagger(100)
// })


// anime({
//   targets : ".box1",
//   translateX : 250,
//   easing : "linear",
//   backgroundColor : "#000", //도착지점으로 가면서 컬러가 변경
//   loop : true,
//   direction : "alternate",
//   borderRadius : "50%"
// })
// anime({
//   targets : ".box2",
//   translateX : 280,
//   translateY : 300,
//   duration : 1000,
//   delay : 1000,
//   easing : "easeInOutQuint", //https://easings.net/ko
//   loop : true,
//   direction : "alternate",
// })
// anime({
//   targets : ".box3",
//   translateX : {
//     value : 400,
//     duration : 1500,
//     delay : 1000
//   },
//   rotate : {
//     value : 360,
//     duration : 1200
//   }
// })


// let tl = anime.timeline({ //타임라인을 쓰면 하나하나 나눠서 애니메이션을 줄 수 있다.
//   easing : "linear",
//   duration : 1000
// })
// tl.add({
//   targets : ".circle1",
//   translateX : 500
// })
// .add({ //체이닝기법 (tl생략)
//   targets : ".circle1",
//   translateY : 500
// })
// .add({
//   targets : ".circle1",
//   translateX : 0
// })
// .add({
//   targets : ".circle1",
//   translateY : 0
// })
// .add({
//   targets : ".circle2",
//   scale : 1.5,
//   rotate : 360,
//   borderRadius : 0
// })


// anime({
//   targets : "ul li",
//   translateY : function(el, i) {
//     if(i % 2 == 0){
//       return 80;
//     } else {
//       return -80;
//     }
//   },
//   opacity : 1,
//   easing : "linear",
//   duration : 1500,

//   // delay : function(el, i) {
//   //   return i * 300
//   // }
//   delay : anime.stagger(300)
// })


const staggerWrap = document.querySelector("ul");
const fragment = document.createDocumentFragment(); //다른 노드 요소를 담는 임시 컨테이너 역할을 맡기는 메서드 함수
const grid = [9, 5];
const col = grid[0];
const row = grid[1];
const allElem = col * row;

for(let i = 0; i < allElem; i++){
  const li = document.createElement("li");
  fragment.appendChild(li);
}
staggerWrap.appendChild(fragment);

let tl = anime.timeline({
  targets : "ul li",
  delay : anime.stagger(200, {
    grid : [9, 5],
    from : "center"
  }),
  direction : "alternate",
  loop : true
})

tl.add({
  scale : [
    {value : 0.1, easing : "easeOutSine", duration : 500},
    {value : 1, easing : "easeOutQuad", duration : 1200},
  ]
})

.add({
  translateX : anime.stagger(10, {
    grid : [9, 5],
    from : "center",
    axis : "x"
  }),
  translateY : anime.stagger(10, {
    grid : [9, 5],
    from : "center",
    axis : "y"
  }),
  rotate : anime.stagger([0, 90], {
    grid : [9, 5],
    from : "center",
    axis : "x"
  })
})

// anime({
//   targets : "ul li",
//   easing : "linear",
//   duration : 1000,
//   // scale : anime.stagger([0, 1])
//   // scale : anime.stagger([0.1, 1], {
//   //   grid : [9, 3],
//   //   from : "center"
//   // })
//   scale : anime.stagger([0.5, 1], {
//     grid : [9, 3],
//     from : "center",
//     axis : "x",
//   })
// })
