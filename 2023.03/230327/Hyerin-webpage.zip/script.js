$(function() {
  $('.work-images').slick({
    dots: false,
    infinite: true,
    speed: 300,
    slidesToShow: 4,
    slidesToScroll: 2
  });

  $('.header-nav a, .header-hyerin a').click(function(e) {
    $.scrollTo(this.hash || 0, 900);
  });
})