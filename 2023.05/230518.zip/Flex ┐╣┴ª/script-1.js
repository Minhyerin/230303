function sideMenu() {
  const side_menu = document.querySelector(".trigger");
  const gnb = document.querySelector(".gnb");
  const sns = document.querySelector(".sns");
  side_menu.classList.toggle("active");
  gnb.classList.toggle("on");
  sns.classList.toggle("on");
}