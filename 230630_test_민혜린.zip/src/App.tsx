import React from "react";
import logo from "./logo.svg";
import "./App.css";
import Header from "./Component/Header";
import Body from "./Component/Body";
import { styled } from "styled-components";

const Container = styled.div`
  width: 100vw;
  height: 100vh;
  display: flex;
  align-items: center;
  justify-content: center;
`;

const Contents = styled.div`
  width: 400px;
  border-radius: 10px;
  box-shadow: 0px 0px 30px rgba(0, 0, 220, 0.2);
  padding: 50px;
`;

function App() {
  return (
    <Container>
      <Contents>
        <Header />
        <Body />
      </Contents>
    </Container>
  );
}

export default App;
