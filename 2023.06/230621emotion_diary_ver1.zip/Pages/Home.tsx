import Button from "../Component/button";
import Editor from "../Component/Editor";
import Header from "../Component/Header";

const Home = () => {
  return (
    <div>
      <Header
        title={"Home"}
        leftChild={
          <Button
            type="positive"
            text={"긍정버튼"}
            onClick={() => {
              alert("positive button");
            }}
          />
        }
        rightChild={
          <Button
            type="negative"
            text={"부정버튼"}
            onClick={() => {
              alert("negative button");
            }}
          />
        }
      />

      <Editor
        initData={console.log("hi")}
        onSubmit={() => {
          alert("작성완료 버튼을 클릭했음");
        }}
        content={console.log("hi")}
      />
    </div>
  );
};

export default Home;
