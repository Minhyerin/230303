// test1
// 사용자로부터 대.소문자가 섞인 영단어를 받아서 대문자는 소문자로, 소문자는 대문자로 콘솔창에 출력

// const eng = prompt("영단어를 입력하세요");

// function solution(eng) {
//   // let answer = [];
//   let answer = "";
//   // for(let i = 0; i < eng.length; i++){
//   //   if(eng[i] === eng[i].toUpperCase()) {
//   //     answer.push(eng[i].toLowerCase());
//   //   } else {
//   //     answer.push(eng[i].toUpperCase());
//   //   }
//   // }
//   for(let el of eng) {
//     if(el === el.toUpperCase()) {
//       answer += el.toLowerCase();
//     } else {
//       answer += el.toUpperCase();
//     }
//   }
//   // console.log(answer.join(""));
//   console.log(answer);
// }

// solution(eng);


// test2
// 사용자로부터 대소문자가 섞인 영단어를 받아서 모든 문자를 대문자로 출력

// let str = String(prompt("영어 단어를 입력해주세요"));
// function solution(e) {
//   let answer = "";
//   for(let el of e) {
//     if(el === el.toLowerCase()) {
//       answer += el.toUpperCase();
//     } else {
//       answer += el;
//     }
//   }
//   console.log(answer);
// }
// solution(str);



// test3
// 사용자로부터 대소문자가 섞인 영단어를 받아서 해당 단어중에서 대문자가 총 몇개인지 확인 후 00단어에서 대문자는 총 00개 입니다 출력

// let str = String(prompt("영어 단어를 입력해주세요"));
// function solution(str) {
//   let answer = 0;
//   for(let el of str) {
//     if(el === el.toUppercase) {
//       answer++;
//     }
//   }
//   console.log(answer)
//   return answer;
// }
// solution(str);



// test4
// 사용자로부터 대소문자가 섞인 영단어를 받아서 해당 단어중에서 찾고싶은 단어가 무엇인지 받으세요! 찾고싶은 단어 00은 총 00개 있습니다

// let str = String(prompt("영어 단어를 입력해주세요"));
// let n = prompt("찾고싶은 단어는 무엇인가요");
// function solution(str, n) {
//   let answer = 0;
//   for(let i = 0; i < str.length; i++) {
//     if(str[i] === n) {
//       answer++;
//     }
//   }
//   let key = console.log(`"${str}"중에서 찾고싶은 단어 ${n}은 총 ${answer}개 있습니다.`);
//   return key;
// }
// solution(str, n);


// test5
// 사용자로부터 대문자 A를 받았을때 콘솔창에 #으로 출력 (단 소문자 a를 받았을때도 동일하게 #출력)

let str = String(prompt("영어 단어를 입력해주세요"));
function solution(str) {
  let answer = "";
  for(let el of str) {
    if(el === "a" || el === "A") {
      answer += "#";
    } else {
      answer += el;
    }
  }
  console.log(answer);
}
solution(str);

// function solution(e) {
//   let answer = e;
//   answer = answer.replace("A", "#");
//   answer = answer.replace("a", "#");
//   return answer;
// }