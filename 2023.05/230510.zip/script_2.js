// let email = prompt("이메일을 입력하세요");
// let id = email.split("@")[0];
// let domain = email.split("@")[1];

// let maskingMail = [];
// maskingMail.push(id[0]);
// maskingMail.push(id[1]);
// maskingMail.push(id[2]);
// maskingMail.push(id[3]);
// maskingMail.push(id[4]);
// maskingMail.push("*");
// maskingMail.push("*");
// maskingMail.push("*");
// maskingMail.push("*");
// maskingMail.push("*");

// let emailMasking = maskingMail.join("") + "@" + domain;
// document.write(emailMasking);


const classmate = [
  {
    name : "짱구",
    age :  8,
    school : "그린아카데미"
  },
  {
    name : "철수",
    age :  9,
    school : "그린아카데미"
  }
]

let mine = classmate.filter((data) => (data.age) = 8);




const lanking = [
  {lank : 1, name : "레드향"},
  {lank : 2, name : "샤인머스켓"},
  {lank : 3, name : "산청딸기"},
  {lank : 4, name : "한라봉"},
  {lank : 5, name : "사과"},
  {lank : 6, name : "애플망고"},
  {lank : 7, name : "딸기"},
  {lank : 8, name : "천혜향"},
  {lank : 9, name : "과일선물세트"},
  {lank : 10, name : "귤"},
]

let topFive = lanking.filter((data) => (data.lank) <= 5);
