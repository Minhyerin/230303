// 이벤트 객체 : 이벤트가 발생하게 되었을때 어떤 요소에서 어떤 이벤트가 발생했는지에 대한 정보가 포함된 객체
// 객체 - 속성(프로퍼티), 기능(메서드= 함수) 을 가지고있다

//preventDefault() => 대표적인 이벤트 객체 내 메서드 (요소의 기본 속성값을 취소 및 무력화하는 메서드)
//이벤트 객체 내 프로퍼티 종류 : 
//pageX, pageY(현재 문서기준으로 이벤트 발생한 가로.세로 위치)
// target :  이벤트요소.target:이벤트가 발생한 대상 반환 / (e.target)

//마우스이벤트. pageX, pageY 활용 클릭한 지점의 좌표값을 출력하기
// const box = document.querySelector("#box");
// box.addEventListener("click", (e) => {
//   alert(`이벤트 발생 위치 : ${e.pageX}, ${e.pageY}`);
// })

//키보드이벤트 e.code 입력한 키의 코드값 /  e.key 입력한 키보드값
// const body = document.body;
// const result =  document.querySelector("#result");

// body.addEventListener("keydown", (e) => {
//   result.innerText = `code: ${e.code}, key: ${e.key}`
// })

//이미지 슬라이더 만들어보기
// 1. 이미지를 출력할 공간에 대한 정의
// 2. 5장의 각각의 이미지에대한 선택을 정의
// (이미지를 배열 객체로 정리)
// 3. 버튼에 대한 기능정의 - 왼쪽을 클릭 한장씩 돌고 오른쪽클릭 반대로 한장씩 돌기
// 4. 만약에 이미지가 처음, 혹은 마지막에 도착했을때 원점으로 다시 돌아가게.
window.addEventListener("contextmenu", (e) => { //바로가기버튼 클릭이벤트
  e.preventDefault(); //사용하지못하게 막기
  this.alert(`오른쪽 버튼을 사용할 수 없습니다.`)
});
const container = document.querySelector("#container");
const pics = ["pic-1.jpg", "pic-2.jpg", "pic-3.jpg", "pic-4.jpg", "pic-5.jpg","pic-6.jpg"];

container.style.backgroundImage = `url(/img/${pics[0]})`;

const arrows = document.querySelectorAll(".arrow");
let i = 0;

arrows.forEach((e)=> {
  e.addEventListener("click", (e) => {
    if(e.target.id === "left") {
      i--;
      if(i < 0) {
        i = pics.length-1;
      }
    } else if (e.target.id === "right") {
      i++;
      if(i >= pics.length) {
        i = 0;
      }
    }
    container.style.backgroundImage = `url(img/${pics[i]})`;
  })
})
