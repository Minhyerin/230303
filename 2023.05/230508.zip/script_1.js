//geolocation

// const getLocation = document.querySelector("#getLocation");
// getLocation.addEventListener('click', (e) => {
//   e.preventDefault();
//   if(navigator.geolocation) {
//     navigator.geolocation.getCurrentPosition(showPosition, errorPosition);
//   } else {
//     alert("지오로케이션을 지원하지 않습니다.");
//   }
// });

// function showPosition(position) {
//   document.querySelector("#result").innerHTML = `
//   <b>경도 : </b>${position.coords.latitude.toFixed(2)}, <b>위도 : </b>${position.coords.longitude.toFixed(2)}
//   `;
// };

// function errorPosition(err) {
//   alert(err.message);
// }

const getLocation = document.querySelector("#getLocation");
getLocation.addEventListener('click', (e) => {
  e.preventDefault();

  if(navigator.geolocation) {
    navigator.geolocation.getCurrentPosition(showPosition, errorPosition);
    const options = {
      enableHighAccuracy : true,
      timeOut : 5000,
      maximumAge : 0
    };

    let watchId = navigator.geolocation.watchPosition(showPosition, errorPosition, options);

    setTimeout(function() {
      navigator.geolocation.clearWatch(watchId);
    }, 30000);
  } else {
    alert("지오로케이션을 지원하지 않습니다.")
  }
})

function showPosition(position) {
  document.querySelector("#result").innerHTML = `
  <b>경도 : </b>${position.coords.latitude},
  <b>위도 : </b>${position.coords.longitude}
  `
};

function errorPosition(err) {
  alert(err.message)
};