const button = document.querySelector("button");
const email = document.querySelector("#userEmail");
const result =  document.querySelector("#result");

button.addEventListener("click", (e) => {
  e.preventDefault();

  let username = "";
  let domain = "";

  if(email.value !== "") {
    username = email.value.split("@")[0];
    username = username.substring(0, 2);
    domain = email.value.split("@")[1];
    result.innerText = `${username}...@${domain}`;
    email.value = "";
  }
})