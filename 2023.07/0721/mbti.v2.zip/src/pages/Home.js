import React from "react";
import { styled } from "styled-components";
import "bootstrap/dist/css/bootstrap.min.css";
import { Button } from "react-bootstrap";

import PangImage from "../assets/ggompang.jpeg";
import { useNavigate } from "react-router-dom";

const Container = styled.div`
  width: 100%;
  height: 100vh;

  display: flex;
  justify-content: center;
  align-items: center;
  background-color: beige;
`;

const Wrapper = styled.div`
  width: 100%;
  height: 100%;
  border-radius: 30px;
  border: 1px solid #eee;

  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  gap: 30px;
`;
const Header = styled.div`
  font-size: 40px;
  display: flex;
  justify-content: center;
  align-items: center;
`;

const Contents = styled.div`
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  gap: 20px;
`;

const Title = styled.div`
  font-size: 30px;
  color: tomato;
  border-bottom: 2px solid tomato;
`;
const LogoImage = styled.div`
  margin-top: 10px;
`;

const Desc = styled.div`
  font-size: 20px;
  margin-top: 20px;
  margin-bottom: 20px;

  background-color: #fff;
  padding: 0 10px;
  color: #333;
`;

const Home = () => {
  const navigation = useNavigate();
  const handleClickButton = () => {
    navigation("/question");
  };
  return (
    <Container>
      <Wrapper>
        <Header>예비집사 판별기</Header>
        <Contents>
          <Title>나에게 맞는 주인님은?</Title>
          <LogoImage>
            <img
              className="rounded-circle"
              src={PangImage}
              width={350}
              height={350}
            />
          </LogoImage>
          <Desc>MBTI를 기반으로 하는 나랑 잘 맞는 고양이 찾기</Desc>
          <Button variant="danger" onClick={handleClickButton}>
            테스트 시작하기
          </Button>
        </Contents>
      </Wrapper>
    </Container>
  );
};

export default Home;
