// 사용자로부터 2개의 숫자를 받아서 두 숫자의 최대 공약수를 구하는 함수를 작성하고, 해당 값을 화면에 출력해주세요 (*최대공약수 = 두 수 모두 나누어 떨어지는 수 중에서 가장 큰값 / ex) 4, 12의 최대  공약수는 4) (*화면에 "숫자1" 과 "숫자2" 의 최대공약수 : )

// 1. 두 숫자가 특정값에 동일하게 나누어져야 한다.
// 2. 그 특정값 중에서 가장 큰 값을 찾아야한다.

/*
const first = parseInt(prompt("첫번째 숫자"));
const second = parseInt(prompt("두번째 숫자"));

function getGCD(n, m) {
  let max = n > m ? n : m; // max에는 두 값중 큰 값이 들어간다.
  let GCD = 0;
  for(let i = 1; i <= max; i++){//인덱스 값을 가져온느것이 아니라 i는 1부터시작이고, 두 값의 max값까지 커져야함
    if(n % i === 0 && m % i === 0) { 
      GCD = i; //공약수 후보 ( 두 수를 나눌 수 있는 값)를 재할탕
    }
  }
  return GCD;
}
document.write(`${first} 와 ${second}의 최대공약수 : ${getGCD(first, second)}`);
*/

// DOM (*문서 객체 모델) = Document Object Model
// 자바스크립트를 왜 배우나요? 화면을 동적으로 구현하기 위해 => 문서객체 모델에 접근해야한다
// 문서 객체 모델(DOM)은 메모리에 웹 페이지 문서 구조를 표현함으로써 스크립트 및 프로그래밍 언어와 페이지를 연결합니다
// DOM은 문서를 논리 트리로 표현합니다. 트리의 각 브랜치는 노드에서 끝나며, 각 노드는 객체를 갖습니다. DOM 메서드를 사용하면 프로그래밍적으로 트리에 접근할 수 있습니다. 이를 통해 문서의 구조, 스타일, 콘텐츠를 변경할 수 있습니다.

// 문서객체 모델의 최상위 클래스는 : Document객체
// Document > body , h1, p, input = 객체는 : 속성(property) 과 기능(mathod) 를 가진다.
// 객체 = "요소", "노드" 라고도 부른다. 
// 요소에 접근한다

// 요소에 접근할 수 있는 함수 
// 1. querySelector() 무조건 (단일)낱개 요소에 접근, 매개변수에 입력한 선택자 접근. 해당 선택자가 document 안에 다수 존재하는 경우, 가장 첫번째로 선택된 요소에 접근.
// 2. querySelectorAll() : 매개변수에 입력한 선택자를 가진 요소에 접근한다. 배열객체로 가져온다. 인덱스값을 가진다. 
// / <==> 차이 : element 가 들어가있는경우 요소 노드까지만 접근가능, query : 텍스트노드, 속성노드까지 접근 최근에는 쿼리를 더 많이 사용
// 4. getElementById() : 
// 5. getElementsByClassName() :
// 6. getElementsByTagName() :

// 요소 데이터 가져오는 방법 및 수정
// 웹 요소.innertText =  수정내용
// 웹 요소.inneHTML = 수정내용
// 웹 요소.textContent = 수정내용

// document.querySelector("#desc").innerText  //웹브라우저 화면에 있는 내용을 그대로 
// '이름 : 아이유'
// document.querySelector("#desc").innerHTML  //태그 속성까지 가져온다
// '\n      <p class="user">이름 :  아이유</p>\n      <p class="user" style="display:none;">주소 : 서울시</p>\n      <p class="user" style="display:none;">연락처 : 010-1234-5678</p>\n    '
// document.querySelector("#desc").textContent  //inneHTML 보다는 덜 자세함 태그까지는 불러오지않음
// '\n      이름 :  아이유\n      주소 : 서울시\n      연락처 : 010-1234-5678\n    '

// document.querySelector("#desc").innerText = "이름 : 민혜린 "
// '이름 : 민혜린 

/*
const userName = document.querySelector("#desc p");
const pfImg = document.querySelector("#profile img");

userName.onclick = () => userName.innerHTML = `이름 : <b>아이돌</b>`;
pfImg.onclick = () =>  pfImg.src = "/iu2.jpg";
*/

// CSS속성에 접근하고 스타일을 수정하는 방법
// 수정하고 싶은 요소.style.속성명 = "바꾸고싶은 스타일";
/*
const title = document.querySelector("#title");
title.onclick = () => { //이벤트 핸들러
  title.style.backgroundColor = "black";
  title.style.color = "white";
}
*/

// ClassList 속성(프로퍼티) 사용 하면 해당요소의 클래스값을 배열객체 형태로 칮아준다. 별도로 가져올수 있다. 하나의 요소에 각각의 클래스를 부여해서 각각 다른 이벤트를 주고싶을때.
/*
document.querySelector("#desc p").classList;
DOMTokenList(2) ['user', 'clicked', value: 'user clicked']
0 : "user"
1 : "clicked"
length : 2
value : "user clicked"
*/
// 선택한요소.classList.add("클래스명") : 선택한요소에 클래스명을 추가할때 사용
// 선택한요소.classList.remove("클래스명") : 선택한요소에 클래스명을 삭제할때 사용
// 선택한요소.classList.contains("클래스명") : 선택한요소에 클래스명이 있는지 여부 확인하는 함수.

// 클릭했을때 스타일 적용, 또 클릭했을때 지우기.
/*
const title = document.querySelector("#title");
title.onclick = () => {
  if(!title.classList.contains("clicked")) {
    title.classList.add("clicked");
  } else {
    title.classList.remove("clicked");
  }
} 
*/
// ==> 복잡 그래서
// 선택한요소.classList.toggle("클래스명") : 선택한요소에 클래스명이 있는지 여부 확인하여 추가 및 삭제 반복
/*
const title = document.querySelector("#title");
title.onclick = () => {
  title.classList.toggle("clicked");
}
*/

//day&night 모드

const bg = document.querySelector("body")
const btn = document.querySelector("button");

btn.onclick = () => {
  bg.classList.toggle("night");

  if(!bg.classList.contains("night")) {
    btn.innerText = "Night Mode"
  } else {
    btn.innerText = "Day Mode"
  }
}

