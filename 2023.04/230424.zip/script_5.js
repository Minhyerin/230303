//정규표현식 : 특정 패턴을 사용해서 문자열을 표현하는 언어

//숫자 클래스
//공백 클래스
//단어 클래스

// 숫자 digit 클래스 : 
// \d : 0~9까지의 숫자
// \D : 숫자가 아닌 모든 문자

// 공백 space 클래스 :
// \s : 공백, 탭 줄바꿈
// \S : 공백이 아닌 모든 문자

// 단어 word 클래스 :
// \w : 단어에 들어가는 문자 및 숫자 의미
// \W : 단어에 들어가지 않는 모든 문자

// let regexp = /\d{3}/; //0부터 9사이의 숫자 중에서 3자리의 숫자를 찾아와라
// regexp.test(123);
// true
// regexp.test(12);
// false

// let str = "ES2023 is powerful!";
// str.match(/is/);
// ['is', index: 7, input: 'ES2023 is powerful!', groups: undefined]
// str.match(/es6/);
// null
// str.replace(/ES2023/, "ES6");
// 'ES6 is powerful!'
// /es/.test(str);
// false
// /es/i.test(str); //i : 대소문자 가리지 않고
// true
// /es/g.test(str);
// false
// /es/gi.test(str);
// true

// let hello = "Hello, everyone";
// undefined
// /^H/.test(hello);
// true
// /^h/.test(hello);
// false

// /one$/.test(hello);
// true

// "ES2023".match(/[0-9]/g);
(4) ['2', '0', '2', '3']