import React from "react";
import { Container, Form, Button } from "react-bootstrap";
import { useNavigate } from "react-router-dom";
import { useDispatch } from "react-redux";
import { useState } from "react";
import { authenticateAction } from "../redux/Actions/authenticateAction";
import { useSelector } from "react-redux";

const Login = ({ setAuthenticate, to }) => {
  const [id, setId] = useState("");
  const [password, setPassword] = useState("");
  const trueOk = useSelector((state) => state.auth.authenticate);

  console.log("tototo", to);
  const navigate = useNavigate();
  const dispatch = useDispatch();

  const login = (event) => {
    event.preventDefault();
    setAuthenticate(trueOk);
    dispatch(authenticateAction.login(id, password));
    navigate("/");
  };

  return (
    <Container className="login-area">
      <Form className="login-form" onSubmit={login}>
        <Form.Group className="mb-3" controlId="formBasicEmail">
          <Form.Label>Email address</Form.Label>
          <Form.Control
            onChange={(e) => setId(e.target.value)}
            value={id}
            type="email"
            placeholder="Enter email"
          />
        </Form.Group>

        <Form.Group className="mb-3" controlId="formBasicPassword">
          <Form.Label>Password</Form.Label>
          <Form.Control
            onChange={(e) => setPassword(e.target.value)}
            value={password}
            type="password"
            placeholder="Password"
          />
        </Form.Group>

        <Button variant="danger" type="submit">
          Login
        </Button>
      </Form>
    </Container>
  );
};

export default Login;
