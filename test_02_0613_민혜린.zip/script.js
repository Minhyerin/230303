const input = document.querySelector("input");
const btnSave = document.querySelector(".btnSave");
const btnRead = document.querySelector(".btnRead");

const key = "mykey";

btnSave.addEventListener("click", (e) => {
  e.preventDefault();
  localStorage.setItem(key, input.value);
  input.value = "";
});

btnRead.addEventListener("click", (e) => {
  e.preventDefault();
  let readValue = localStorage.getItem(key);
  input.value = readValue;
});