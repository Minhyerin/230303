$(function() {
  let beforeMenu = null;

  $(".gnb > button > a").on("mouseover", function() {
    if(beforeMenu) {
      beforeMenu
      .css({
        "background" : "none"
      }); //이벤트가적용되지 않았을때를 선 정의.
    };
    $(this)
    .css({
      "background-color" : "#0ff"
    }); //이벤트가 정의 되었을때.
    beforeMenu = $(this); //원래값을 할당
  });

  $(".gnb").on("mouseleave", function() {
    if(beforeMenu) {
      beforeMenu
      .css({
        "background" : "none"
      })
    }
  })
})