const openButton = document.querySelector('.open');
const closeButton = document.querySelector('.close');
const container = document.querySelector('.container');

openButton.addEventListener('click', () => {
  openButton.style.display = 'none';
  container.style.display = 'flex';
})

closeButton.addEventListener('click', () => {
  container.style.display = 'none';
  openButton.style.display = 'block';
})

$('.bxslider').bxSlider({
  mode: 'fade',
  speed: 600,
  auto: true,
  pause: 3000,
  captions: true,
});

$( function() {
  $( "#datepicker" ).datepicker();
});