import React from "react";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faSearch, faUser } from "@fortawesome/free-solid-svg-icons";
import { useNavigate } from "react-router-dom";
const Navbar = () => {
  const menuList = [
    "여성",
    "남성",
    "신생아/유아",
    "아동",
    "H&M Home",
    "Sale",
    "지속가능성",
  ];
  const navigate = useNavigate();
  // const goToLogin = () => {
  //   navigate("/login");
  // };

  const search = (e) => {
    if (e.key == "Enter") {
      let keyword = e.target.value;
      console.log("keyword", keyword);
    }
  };

  return (
    <div>
      <div className="nav-header">
        <div>
          <FontAwesomeIcon icon={faUser} />
          <span
            onClick={() => navigate("/login")}
            style={{ cursor: "pointer" }}
          >
            로그인
          </span>
        </div>
      </div>
      <div className="nav-logo">
        <img
          width={100}
          src="https://upload.wikimedia.org/wikipedia/commons/thumb/5/53/H%26M-Logo.svg/220px-H%26M-Logo.svg.png"
        />
      </div>
      <div className="nav-menu-area">
        <ul className="menu">
          {menuList.map((menu, index) => (
            <li>
              <a href="#" key={index}>
                {menu}
              </a>
            </li>
          ))}
        </ul>
        <div className="search-box">
          <FontAwesomeIcon icon={faSearch} />
          <input
            type="text"
            placeholder="제품 검색"
            onKeyPress={search}
          ></input>
        </div>
      </div>
    </div>
  );
};

export default Navbar;
