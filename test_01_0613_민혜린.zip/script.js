setInterval(() => {
  const today = new Date();
  const hour = today.getHours();
  const min = today.getMinutes();
  const sec = today.getSeconds();

  const lineHour = document.querySelector(".lineHour");
  const lineMin = document.querySelector(".lineMin");
  const lineSec = document.querySelector(".lineSec");

  const degH = hour * (360 / 12) + min * (360 / 12 / 60);
  const degM = min * (360 / 60);
  const degS = sec * (360 / 60);

  lineHour.style.transform = `rotate(${degH}deg)`;
  lineMin.style.transform = `rotate(${degM}deg)`;
  lineSec.style.transform = `rotate(${degS}deg)`;

  console.log(hour);
}, 1000);