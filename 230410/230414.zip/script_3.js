

const first = document.querySelector("#first");
//const first = document.querySelector("#first").value; 로 받아오면 문자열이되어버림.

const second = document.querySelector("#second");
const btn = document.querySelector("button");
const result = document.querySelector("#result");

btn.onclick = () => {
  function getGCD(n, m) {
    let max = n > m ? n : m;
    let gcd = 1;
    for(let i = 1; i <= max; i++){
      if(n % i === 0 && m % i === 0){
        gcd = i;
      }
    }
    return gcd;
  }
  result.innerText = getGCD(first.value, second.value);
}