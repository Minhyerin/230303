import React from "react";
import { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
//파라미터값을 가져오기위한 훅
import { Container, Row, Col, Dropdown, Button } from "react-bootstrap";
import DropdownItem from "react-bootstrap/esm/DropdownItem";

const ProductDetail = () => {
  let { id } = useParams(); //파라미터 값은 객체값을 반환
  const [product, setProduct] = useState(null); //초기값이 null이면 에러가뜸.그래서 []을 넣으면 해결되거나
  const [loading, setLoading] = useState(false); //로딩값을 하나더 만들고
  const getProductDetail = async () => {
    let url = `http://localhost:3004/products/${id}`;
    let response = await fetch(url);
    let data = await response.json();
    console.log(data);
    setLoading(false); //로딩값
    setProduct(data);
  }; //외부데이터 불러오기
  useEffect(() => {
    getProductDetail();
  }, []);
  if (loading || product == null) return <h1>Loading</h1>; //로딩값출력

  return (
    <Container>
      <Row>
        <Col className="product-detail-img">
          <img src={product.img} />
        </Col>
        <Col>
          <div className="product-info">{product.title}</div>
          <div className="product-info">{product.price}</div>
          <div className="choice">
            {product.choice ? "Conscious Choice" : ""}
          </div>
          <Dropdown className="drop-down">
            <Dropdown.Toggle variant="outline-dark" id="dropdown-basic">
              사이즈 선택
            </Dropdown.Toggle>

            <Dropdown.Menu>
              {product.size.map((item) => (
                <Dropdown.Item href="#/action-1">{item}</Dropdown.Item>
              ))}
            </Dropdown.Menu>
          </Dropdown>
          <Button className="add-button" variant="dark">
            추가
          </Button>
        </Col>
      </Row>
    </Container>
  );
};

export default ProductDetail;
