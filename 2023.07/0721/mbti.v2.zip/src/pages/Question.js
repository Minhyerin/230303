import React, { useState } from "react";
import { styled } from "styled-components";
import { ProgressBar, Button } from "react-bootstrap";
import { QuestionData } from "../assets/data/questiondata";
import { createSearchParams, useNavigate } from "react-router-dom";

const Wrapper = styled.div`
  width: 100%;
  height: 100vh;
`;
const Title = styled.div`
  font-size: 30px;
  text-align: center;
  margin: 30px 0;
  height: 200px;

  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  h1 {
    color: tomato;
  }
`;
const ButtonGroup = styled.div`
  display: flex;
  flex-direction: row;
  justify-content: center;
  align-items: center;
`;
// 왼쪽버튼 클릭시 : 1점 , 오른쪽 버튼 클릭시 : 0점
// 각 항목별 합계 점수가 2점 이상이 되면, 무조건 왼쪽 타입이라고 정의한다.

const Question = () => {
  const [questionNo, setQuestionNo] = useState(0); //질문 총 갯수 카운트
  const [totalScore, setTotalScore] = useState([
    { id: "EI", score: 0 },
    { id: "SN", score: 0 },
    { id: "TF", score: 0 },
    { id: "JP", score: 0 },
  ]); //각 질문당 점수 부여

  const navigate = useNavigate();

  // const handleClickButtonA = (no, type) => {
  //   if (type == "EI") {
  //     //기존 스코어에 더할 값 계산
  //     const addScore = totalScore[0].score + no;
  //     // 새로운 객체 생성
  //     const newObject = { id: "EI", score: addScore };
  //     //스플라이스 함수 활용 새로운 객체로 대체
  //     totalScore.splice(0, 1, newObject);
  //   } else if (type == "SN") {
  //     const addScore = totalScore[1].score + no;
  //     const newObject = { id: "SN", score: addScore };
  //     totalScore.splice(1, 1, newObject);
  //   } else if (type == "TF") {
  //     const addScore = totalScore[2].score + no;
  //     const newObject = { id: "TF", score: addScore };
  //     totalScore.splice(2, 1, newObject);
  //   } else {
  //     const addScore = totalScore[3].score + no;
  //     const newObject = { id: "JP", score: addScore };
  //     totalScore.splice(3, 1, newObject);
  //   }
  //   setQuestionNo(questionNo + 1);
  // };

  // const handleClickButton = (no, type) => {
  //   totalScore.map((item, idx) => {
  //     if (item.id === type) {
  //       const addScore = totalScore[idx].score + no;
  //       const newObject = { id: type, score: addScore };
  //       totalScore.splice(idx, 1, newObject);
  //     }
  //   });
  //   setQuestionNo(questionNo + 1);
  // };

  const handleClickButton = (no, type) => {
    const newScore = totalScore.map((item) =>
      item.id === type ? { id: item.id, score: item.score + no } : item
    );
    setTotalScore(newScore);

    if (QuestionData.length !== questionNo + 1) {
      //다음번 문제로 이동
      setQuestionNo(questionNo + 1);
    } else {
      const mbti = newScore.reduce(
        (acc, curr) =>
          acc +
          (curr.score >= 2 ? curr.id.substring(0, 1) : curr.id.substring(1, 2)),
        ""
      );
      navigate({
        pathname: "/result",
        search: `?${createSearchParams({
          mbti: mbti,
        })}`,
      });
    }
  };

  // const handleClickButtonB = (no, type) => {
  //   totalScore.map((item, idx) => {
  //     if (item.id === type) {
  //       const addScore = totalScore[idx].score + no;
  //       const newObject = { id: type, score: addScore };
  //       totalScore.splice(idx, 1, newObject);
  //     }
  //   });
  //   setQuestionNo(questionNo + 1);
  // };

  // const handleClickButtonB = (no, type) => {
  //   if (type == "EI") {
  //     //기존 스코어에 더할 값 계산
  //     const addScore = totalScore[0].score + no;
  //     // 새로운 객체 생성
  //     const newObject = { id: "EI", score: addScore };
  //     //스플라이스 함수 활용 새로운 객체로 대체
  //     totalScore.splice(0, 1, newObject);
  //   } else if (type == "SN") {
  //     const addScore = totalScore[1].score + no;
  //     const newObject = { id: "SN", score: addScore };
  //     totalScore.splice(1, 1, newObject);
  //   } else if (type == "TF") {
  //     const addScore = totalScore[2].score + no;
  //     const newObject = { id: "TF", score: addScore };
  //     totalScore.splice(2, 1, newObject);
  //   } else {
  //     const addScore = totalScore[3].score + no;
  //     const newObject = { id: "JP", score: addScore };
  //     totalScore.splice(3, 1, newObject);
  //   }
  //   setQuestionNo(questionNo + 1);
  // };
  // 총 질문 갯수 카운팅

  return (
    <Wrapper>
      <ProgressBar
        striped
        variant="danger"
        now={(questionNo / QuestionData.length) * 100}
        style={{ marginTop: "20px" }}
      />
      <Title>
        <h1>Q. {questionNo}</h1>
        {QuestionData[questionNo].title}
      </Title>
      <ButtonGroup>
        <Button
          onClick={() => handleClickButton(1, QuestionData[questionNo].type)}
          style={{
            width: "40%",
            minHeight: "200px",
            fontSize: "18px",
            backgroundColor: "tomato",
            border: "none",
            borderRadius: "30px",
          }}
        >
          <h1>A</h1>
          {QuestionData[questionNo].answera}
        </Button>
        <Button
          onClick={() => handleClickButton(0, QuestionData[questionNo].type)}
          style={{
            width: "40%",
            minHeight: "200px",
            fontSize: "18px",
            marginLeft: "20px",
            backgroundColor: "tomato",
            border: "none",
            borderRadius: "30px",
          }}
        >
          <h1>B</h1>
          {QuestionData[questionNo].answerb}
        </Button>
      </ButtonGroup>
    </Wrapper>
  );
};

export default Question;
