const Edit = () => {
  return (
    <div>
      <div>Edit페이지 입니다.</div>
    </div>
  );
};

export default Edit;
