import "./App.css";
import { styled } from "styled-components";
import {
  motion,
  useMotionValue,
  useTransform,
  useViewportScroll,
  AnimatePresence,
} from "framer-motion";
import { useRef, useEffect, useState } from "react";

const Wrapper = styled(motion.div)`
  width: 100vw;
  height: 100vh;
  display: flex;
  align-items: center;
  justify-content: center;
`;
const BiggerBox = styled.div`
  width: 600px;
  height: 600px;
  background-color: rgba(255, 255, 255, 0.4);
  border-radius: 40px;
  display: flex;
  justify-content: center;
  align-items: center;
  overflow: hidden;
`;

const Grid = styled.div`
  display: grid;
  grid-template-columns: repeat(3, 1fr);
  width: 50vw;
  gap: 10px;
  div: first-child, div: last-child {
    grid-column: span 2;
  }
`;

const Box = styled(motion.div)`
  width: 200px;
  height: 200px;
  background-color: rgba(255, 255, 255, 1);
  border-radius: 40px;
  box-shadow: 0 2px 3px rgba(0, 0, 0, 0.1), 0 10px 20px rgba(0, 0, 0, 0.06);

  display: grid;
  grid-template-columns: repeat(2, 1fr);
`;

const Overlat = styled(motion.div)`
  width: 100%;
  height: 100%;
  background-color: rgba(0, 0, 0, 0.5);
  position: absolute;
  display: flex;
  justify-content: center;
  align-items: center;
`;
const Circle = styled(motion.div)`
  background: #fff;
  width: 70px;
  height: 70px;
  place-self: center;
  border-radius: 35px;
  box-shadow: 0 2px 3px rgba(0, 0, 0, 0.1), 0 10px 20px rgba(0, 0, 0, 0.06);
`;

const myVars = {
  start: { scale: 0 },
  end: {
    scale: 1,
    rotateZ: 360,
    transition: { type: "spring", duration: 2, delay: 1 },
  },
};

const boxVariants = {
  start: {
    opacity: 0,
    scale: 0.5,
  },
  end: {
    opacity: 1,
    scale: 1,
    transition: {
      type: "spring",
      bounce: 0.5,
      duration: 1,
      delayChildren: 0.3,
      staggerChildren: 0.2,
    },
  },
  hover: {
    scale: 1.2,
    rotateZ: 180,
    boxShadow: "0 0 20px 10px rgba(255, 255, 255, 0.5)",
  },
  tap: {
    borderRadius: "100px",
    scale: 1,
  },
  drag: { backgroundColor: "rgb(46, 204, 113)", transition: { duration: 5 } },
};

const circleVariants = {
  start: {
    y: 20,
    opacity: 0,
  },
  end: {
    y: 0,
    opacity: 1,
  },
};

const hover = {
  scale: 1.2,
  rotateZ: 180,
  backgroundColor: "beige",
  boxShadow: "0 0 20px 10px rgba(255, 255, 255, 0.5)",
};
const tap = {
  borderRadius: "100px",
  scale: 1,
};

// 애니메이션 효과를 주기위해 필요한 것 : 시작(initial). 끝(animate)
// framer motion 에서는 부모요소에 적용한 애니메이션 효과가 자녀요소에게 상속된다

// -800 => 사이즈 2배 / 0 => 정사이즈 / 800 => 0
// useTransform() : 모션값에 따라 애니메이션을 도출
// useMotionValue() : 동적인 모션이 발생되었을 때 위치값을 저장하는 공간
// useViewPortScroll(): scroll시 픽셀값,전체 스크롤 가능 공간 중 비율 찾을때

function App() {
  const biggerBoxRef = useRef();

  const x = useMotionValue(0);
  const motionTest = useTransform(x, [-800, 0, 800], [2, 1, 0]);
  const rotateZ = useTransform(x, [-800, 800], [-360, 360]);
  const gradient = useTransform(
    x,
    [-800, 0, 800],
    [
      "linear-gradient(135deg, rgb(0, 210, 238), rgb(0, 83, 238))",
      "linear-gradient(135deg, rgb(238, 0, 153), rgb(221, 0, 238))",
      "linear-gradient(135deg, rgb(0, 238, 155), rgb(238, 178, 0))",
    ]
  );
  const { scrollYProgress } = useViewportScroll();
  // console.log(x);
  // useEffect(() => {
  //   //motionTest.onChange(() => console.log(motionTest.get()));
  //   scrollY.onChange(() => console.log(scrollY.get(), scrollYProgress.get()));
  // }, [scrollY, scrollYProgress]);

  const [showing, setShowing] = useState(false);
  const [clicked, setClicked] = useState(false);
  const toggle = () => {
    setClicked((prev) => !prev);
  };
  return (
    // <Wrapper style={{ background: gradient }}>
    <Wrapper onClick={toggle}>
      {/* <BiggerBox ref={biggerBoxRef}>
        <Box
          drag
          dragSnapToOrigin
          dragConstraints={biggerBoxRef}
          variants={boxVariants}
          whileHover="hover"
          whileTap="tap"
          whileDrag="drag"
        />
      </BiggerBox> */}
      {/* <Box
        style={{ x, rotateZ, scale: scrollYProgress }}
        drag="x"
        dragSnapToOrigin
      /> */}
      {/* <button onClick={() => setShowing(!showing)}>클릭</button>
      {showing ? <Box /> : null} */}
      <AnimatePresence>
        <Grid>
          <Box layoutId="hello" />
          <Box />
          <Box />
          <Box />
        </Grid>
        {clicked ? (
          <Overlat
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
          >
            <Box layoutId="hello" style={{ width: 400, height: 200 }} />
          </Overlat>
        ) : null}
      </AnimatePresence>
    </Wrapper>
  );
}

export default App;
