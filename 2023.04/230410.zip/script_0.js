$(function () {
  $(document).on("mousemove", function(e) {
    $(".posX").text(e.pageX);
    $(".posY").text(e.pageY);
  });
})

$(function() {
  $(window).on("scroll", function() {
    let sc_Top = $(this).scrollTop();
    let sc_Left = $(this).scrollLeft();

    $(".top").text(sc_Top);
    $(".left").text(sc_Left);
  });
})

$(function() {
  $("#user_id_1, #user_pw_1").on("focus", function() {
    $(this)
    .css({
      "background-color" : "pink"
    });
  });
  $("#user_id_1, #user_pw_1").on("blur", function() {
    $(this)
    .css({
      "background-color" : "#fff"
    });
  });

  $("#frm_2").on("focusin", function() { //상위요소 여야 한다.
    $(this)
    .css({
      "background-color" : "pink"
    });
    $("#frm_2").on("focusout", function() {
      $(this)
      .css({
        "background-color" : "#fff"
      });
    });
  });
})

$(function () {
  $("#btn1")
  .data({
    "text" : "javascript"
  })
  .on({
    "mouseover" : overFnc,
    "mouseout" : outFnc
  });

  $("#btn2")
  .data({
    "text" : "welcome"
  })
  .on({
    "mouseover focus" : overFnc,
    "mouseout blur" : outFnc //사용자의 편의성을 고려하기 위해, 마우스로만 작동되는 것이아니라, 키보드 사용할때도 작동할 수 있도록함
  })

  function overFnc() {
    $(".txt").text($(this).data("text"));
  }
  function outFnc() {
    $(".txt").text("");
  }
})