export function srting1(str1) {
  let newP = document.createElement("p");
  newP.innerText = str1;
  document.querySelector("#log").appendChild(newP);
};