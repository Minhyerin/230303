// 문자열과 배열 변환하는 방법
// let hello = "Hello Goodmorning"
// //특정 테스트만 수정하고싶을때 문자->배열->문자

// 문자열 ->배열 첫번째 (스플릿메서드)
// let str5 = "Hello everyone";
// undefined
// str5.split("");
// (14) ['H', 'e', 'l', 'l', 'o', ' ', 'e', 'v', 'e', 'r', 'y', 'o', 'n', 'e']
// let arr2 = str5.split("");
// undefined
// arr2
// (14) ['H', 'e', 'l', 'l', 'o', ' ', 'e', 'v', 'e', 'r', 'y', 'o', 'n', 'e']


// 문자열 ->배열 두번째 (전개연산자)
// let str5 = "Hello everyone";
// undefined
// let arr3 = [...str5];
// undefined
// arr3
// (14) ['H', 'e', 'l', 'l', 'o', ' ', 'e', 'v', 'e', 'r', 'y', 'o', 'n', 'e']

// 문자열 ->배열 세번째 (array, from)
// arr4 = Array.from(str5);
// (14) ['H', 'e', 'l', 'l', 'o', ' ', 'e', 'v', 'e', 'r', 'y', 'o', 'n', 'e']

// 배열 -> 문자 (join메서드)
// *배열 : 여러개의 객체를 한꺼번에 묶거너ㅏ 일부분을 삭제 및 수정할때 사용할 수 있는 객체

// *배열 생성 방법
// 1. 빈 배열을 만들고 값 할당
// 2. 리터럴 표기법 생성
// 3. Array 객체의 인스턴스 객체로 생성

// 1. 빈배열 만들고 값 할당
// let seasons = [];
// undefined
// seasons[0] = "spring";
// 'spring'
// seasons[1] = "summer";
// 'summer'
// seasons
// (2) ['spring', 'summer']

// 2.리터럴표기법
// let pets = ["dog","cat","mouse"]

// 3. Array 객체 (내장객체)
// let fruits = new Array("사과", "포도");
// undefined
// fruits
// (2) ['사과', '포도']

// 객체 값 변경
// let pets = ["dog","cat","mouse"]
// undefined
// pets[1] = "hamster";
// 'hamster'
// pets
// (3) ['dog', 'hamster', 'mouse']

//객체 새로운 값 부여
// let pets = ["dog","cat","mouse"]
// undefined
// pets[4] = "rabbit";
// 'rabbit'
// pets
// (5) ['dog', 'cat', 'mouse', empty, 'rabbit']

// 배열 = > 반복문을 많이 사용
// let colors = ["red", "green", "blue", "white","black"];
// for(let i = 0; i < colors.length; i++){
//   console.log(colors[i])
// };
// for(color of colors) {
//   console.log(color)
// };
// let aniamls = ["lion", "bear", "bird"];
// aniamls.forEach((aniaml) => {
//   console.log(aniaml)
// });
//매개변수가 2개라면(값과 인덱스)
// aniamls.forEach((animal, i) => {
//   console.log(`animals[${i}] : ${animal}`)
// })
//인자값이 3개라면 (값, 인덱스, 배열)
// aniamls.forEach((animal, i, a) => {
//   console.log(`[${a}] [${i}] : ${animal}`)
// })


//배열과 배열을 합치는 방법 :contcat()
// let vegitable = ["양상추", "토마토", "오이"];
// let meat = ["불고기"];
// let meatBurger = vegitable.concat(meat, "빵");
// // meatBurger
// // (5) ['양상추', '토마토', '오이', '불고기', '빵']

// let meatBurger2 = meat.concat("빵", vegitable);
// // meatBurger2
// // (5) ['불고기', '빵', '양상추', '토마토', '오이']


//배열과 배열을 합치는 방법 : 전개연산자[...]
// let vegitable = ["양상추", "토마토", "오이"];
// let cheese = ["모짜렐라", "슈레드"];
// let cheeseBurger = [...vegitable, ...cheese];

// cheeseBurger
// (5) ['양상추', '토마토', '오이', '모짜렐라', '슈레드']



//배열의 요소 정렬 
// 역순 : reverse()
// 크기 : sort()

// let numbers = [6, 9, 3, 21, 18];
// numbers.reverse();
// numbers
// (5) [18, 21, 3, 9, 6]

// let week = ["sun", "mon", "tue"];
// undefined
// let values = [5, 20, 3, 11, 4, 15];
// undefined
// week.sort();
// (3) ['mon', 'sun', 'tue']
// values.sort();

// (6) [11, 15, 20, 3, 4, 5]
// //알파벳순, 숫자는 앞자리만 보고 판단
// values.sort(function(a,b){
//   if(a>b) return 1;
//   if(a<b) return -1;
//   if(a==0) return 0;
// });
// (6) [3, 4, 5, 11, 15, 20]
// values.sort(function(a,b){
//   return a - b;
// });
// (6) [3, 4, 5, 11, 15, 20] //오름차순 정렬하고싶다 하면 이렇게, 외우기


//배열요소에서 맨끝에 값을 추가하거나 제거하기.
//pop(): 맨 마지막 값을 제거하는 메서드
//push(): 맨 마지막 값을 추가하는 메서드

//배열요소에서 맨앞에 값을 추가하거나 제거하기.
//shift(): 맨 앞에 값을 제거하는 메서드
//unshift(): 맨 앞에 값을 추가하는 메서드


//특정 위치에 요소를 추가하거나 제거하는 메서드
//splice(1) : 1번부터 끝까지 요소를 모두선택해서 제거
//splice(1,2) : 1번부터 2번갯수만큼 요소를 모두선택해서 제거
//splice(1,2, "") : 1번부터 2번 앞에 "" 추가
// let subject = ["html", "css", "java", "react", "typescript"];
// undefined
// subject.splice(2);
// (3) ['java', 'react', 'typescript']
// subject;
// (2) ['html', 'css']
// let brunch = ["egg", "milk", "apple", "banana"];
// undefined
// brunch.splice(2, 0, "cofee", "bread");
// []

//slice(1,2) : 1부터 2번 직전까지 선택
//slice(1개) : 1번 부터 끝까지 요소를 모두 선택
// let subject = ["html", "css", "java", "react", "typescript"];
// undefined
// subject.splice(2);
// (3) ['java', 'react', 'typescript']
// subject;
// (2) ['html', 'css']

// splice 는 원본 배열 수정합니다.
// slice 는 원본 배열을 수정하지 않습니다.
// let colors = ["red", "green", "blue", "white","black"];
// undefined
// let color1 = colors.slice(2);
// undefined
// color1;
// (3) ['blue', 'white', 'black']
// colors;
// (5) ['red', 'green', 'blue', 'white', 'black']
// let color2 = colors.splice(2);
// undefined
// color2;
// (3) ['blue', 'white', 'black']
// colors;
// (2) ['red', 'green']


//(예제)영문소문자로된 
//toUppercase

// let str = prompt("영문 소문자로 된 문자를 입력하세요");
// let firstch = str[0].toUpperCase();
// let remainch = str.slice(1);
// document.write(firstch+remainch);

// let str = prompt("영문 소문자로 된 문자를 입력하세요");
// const result = [str[0].toUpperCase(), str.slice(1)].join(""); //배열을 문자열로 바꿀떄
// document.write(result);