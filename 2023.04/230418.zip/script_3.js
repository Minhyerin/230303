const del = document.querySelectorAll("span"); //배열객체로가져온다.

for(let e of del) {
  e.addEventListener("click", function() {
    this.parentNode.remove();
  });
};