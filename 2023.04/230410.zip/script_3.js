// $(function() {
//   $(".btn_1").on("mouseover focus", function() {
//     alert("Hello");
//   })
// })

//그룹 이벤트 .on() 은 이벤트 셋팅 후 새롭게 생성되거나 복제되는 이벤트 요소 적용 불가. (*라이브 이벤트)

/*
$(function() {
  $(document).on("mouseover focus", ".btn_1.on", function() {
    alert("hello!");
  });
  $(".btn_1").addClass("on");
});
*/
//상기와 같은 그룹 이벤트 방식을 "라이브이벤트 등록 방식"
//$("이벤트대상의 상위요소 선택").on("이벤트종류", "이벤트대상", function(){자바스크립트 코드});



//delegate()이벤트등록 메서드 : 선택한 요소의 하위 요소에 이벤트를 등록할 때 사용.
//one()이벤트등록 메서드 : 이벤트가 1회 발생하면, 자동으로 등록된 이벤트가 제거됩니다.(이벤트가 한번만 발생하고 끝남)
$(function() {
  $(".btn_wrap").delegate(".btn_1.on", "mouseover focus", function() {
    alert("Hello!");
  });
  $(".btn_1").addClass("on");

  $(document).one("mouseover focus", ".btn_2.on", function() {
    alert("Welcome!");
  });
  $(".btn_2").addClass("on");
})


//on() <=> off() : on()메서드로 등록한 이벤트를 제거할때
//delegate() <=> ondelegate() : 
$(function() {
  $(".btn_3").on("mouseover", function(){
    alert("Hello~");
  });
  $(document).delegate(".btn_4", "mouseover", function(){
    alert("Welcome~");
  });

  let btn_4 = $("<p><button class=\"btn_4\">버튼4</button></p>");
  $("#wrap").append(btn_4);

  $(".del_1").on("click", function(){
    $(".btn_3").off("mouseover")
  });
})
