//예외처리 = 오류처리 : 프로그램에서 문제가 발생할때를 대비해서 작업해놓은 코드
// ex. 사용자로부터 특정 숫자를 받아서 어떤 프로그램을 실행시킨다면...
// - 사용자가 숫자를 입력하지 않았을때의 오류
// - 
// *try 문 / catch문 / throw 문
// -try : 실제 오류가 발생했을때 실행할 명령문을 작성하는 곳
// -catch :  발생하 ㅇ오류의 이름 및 설명들이 들어가 있는 곳
// -throw : 개발자가 직접 오류 메세지를 정의할 수 있는 곳
// -console.error() : 오류메세지를 표기할때 사용할 수 있음 

// try {
//   console.log("시작")
//   add()
//   console.log("실행중")
// } catch(err) {
//   console.log(`오류발생 : ${err}`)
// }
// console.log("끝")
////콘솔창 결과
// 시작
// 오류발생 : ReferenceError: add is not defined
// 끝

// try {
//   console.log("시작")
//   add()
//   console.log("실행중")
// } catch(err) {
//   console.error(`오류발생 : ${err}`)
//   console.error(`오류발생 : ${err.name}`)
//   console.error(`오류발생 : ${err.message}`)
// }
// console.log("끝")
// //콘솔창 결과
// 시작
// 오류발생 : ReferenceError: add is not defined
// 오류발생 : ReferenceError
// 오류발생 : add is not defined
// 끝

let json = `{"grade" : 3, "age" : 25}`;
try { //나만의에러메세지
  let user = JSON.parse(json);
  if(!user.name){
    throw "사용자이름이 없습니다!" //함수 혹은 조건문에서 return,brek처럼사용됨. try문에서 오류메세지로 만들고 싶은 경우,
  }
} catch(err) {
  console.error(err)
}
console.log("끝")