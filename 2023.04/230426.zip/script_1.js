// //실습
// const result = document.querySelector("#result");
// //출력공간 정의
// const member1 = ["HTML", "CSS"];
// const member2 = ["CSS", "Javascript", "React"];
// const member3 = ["Javascript", "Typescript"];

// //취합하기
// const subjects = [...member1, ...member2, ...member3];

// //중복되는 값은 제외하기.
// const resultList = new Set();
// subjects.forEach(subject => {
//   resultList.add(subject);
// });

// result.innerHTML = `
//   <ul>
//   ${[...resultList] //원본데이터는 건드리지 않겠다.
//     .map(subject => `<li>${subject}</li>`)
//     .join("") //배열을 문자로 전환할때.
//   }
//   </ul>
// `

//출력공간정의
const result = document.querySelector("#result");
//멤버들의 값 정의
const member1 = ["HTML", "CSS"];
const member2 = ["CSS", "Javascript", "React"];
const member3 = ["Javascript", "Typescript"];

//멤버들의 값들을 하나로 취합
const subjects = [...member1, ...member2, ...member3];

//중복되는 값은 제외하고 하나의 객체로 저장.
const resultList = new Set();
subjects.forEach(subject => {
  resultList.add(subject)
});

result.innerHTML = `<ul>${[...resultList].map(subject => `<li>${subject}</li>`).join("")}</ul>`
