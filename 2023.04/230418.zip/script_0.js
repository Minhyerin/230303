// DOM 활용하기 , DOM 트리 복습, DOM텍스트 노드 추가하기, 속성값이 있는 노드추가, 기존 노드 앞에 새 요소 추가하기, 노드 삭제하기

//내장객체 활용하기

//Dom Tree 이해
// 모든 HTML 태그는 요소 노드가 된다.
// HTML 태그에서 사용하는 텍스트 내용은 자식 노드가 된다.
// HTML 태그에서 속성은 자식 노드가 된다.

// 노드리스트!! 란?
// querySelecterAll() : 복수 요소를 선택 => 노드리스트에 저장
// 만약 html 에 여러개의 p 요소가  있을경우
// document.querySelectorAll('p');

// NodeList(3) [p, p, p]
// 0 : p
// 1 : p
// 2 : p
// length : 3
// document.querySelectorAll('p')[1];
// <p>​CSS​</p>​ //콘솔창에 나타나는 결과값.


//기존에 없던 새로운 노드를 만들어서 추가하고 싶은 경우
// document.createElement(생성하고 싶은 요소명)
//document.createTextNode(생성하고 싶은 텍스트)
//부모노드.appendchile(자식노드) 부모도느 하위에 자식노드추가
//let newP = document.createElement("p");
//let textNode = document.createTextNode("typescript");
//newP.appendchild(textNode);
//document.body.appendchild(newP);
//<p>​typescript​</p>​


//주문하기 버튼 클릭시, 주문하기 아래 영역에 상품명을 출력해보세요
// 1.주문하기 버튼정의
// 2.출력공간 정의
// 3.출력공간에 보여줄 컨텐츠 정의

const orderButton = document.querySelector("#order");
const orderInfo = document.querySelector("#orderInfo");
const title = document.querySelector("h2");

orderButton.addEventListener("click", () => {
  let newP = document.createElement("p");
  let textP = document.createTextNode(title.innerText);

  newP.appendChild(textP);
  newP.style.fontSize = "0.8em";
  newP.style.color = "blue";
  orderInfo.appendChild(newP);
}, {once : true});

