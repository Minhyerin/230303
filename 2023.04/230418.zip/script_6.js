//setInterval 로 메세지창 나오기
// 클릭버튼 클릭후 -> 이벤트: 3초뒤 사라지는 메세지
//셋인터벌
//t셋타임아웃 3000. 리무브

const btn = document.querySelector("#btn");
const notiBox = document.querySelector("#noti-box");

btn.addEventListener("click", () => {
  const noti = document.createElement("div");
  noti.classList.add("noti");
  noti.innerText = "항상 응원합니다";
  notiBox.appendChild(noti);

  setTimeout(() => {
    noti.remove();
  }, 1000);
})