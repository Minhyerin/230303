// 사용자로부터 영어단어를 입력받고 콘솔창을 통해 해당 영어 단어의 가운데 문자만 출력 
// 짝수일 경우 가운데 2개 문자열이 출력

// let str = String(prompt("영어단어를 입력하세요"));

// function solution(str) {
//   let answer = "";
//   let mid = Math.floor(str.length / 2);

//   if(str.length % 2 == 1){
//     answer += str.substring(mid, mid+1);
//   } else {
//     answer += str.substring(mid-1, mid+1);
//   }

//   return answer;
// }

// console.log(solution(str));




// ["good", "time", "good", "time", "student"]
// 에서 중복되는 단어를 제거한 상태로 콘솔창에 출력

const arr = ["good", "time", "good", "time", "student"];

const answer = arr.filter((val, idx) => {
    return arr.indexOf(val) === idx;
  });

console.log(answer);