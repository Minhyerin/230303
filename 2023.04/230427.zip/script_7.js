//서버에 있는 JSON파일을 가져올때 사용하는 객체 이름은?
// XMLHttpRequest() => fetch()
//최근에는 fetch()를 많이 사용 -> promise객체를 반환할 수 있기 때문!

// fetch("student.json");
// Promise {<pending>}

// 프로미스 객체의 진행 단계 (3가지)
// 1.pendding : 프로미스 객체를 만들고 대기중인 상태
// 2.fullfilled : 프로미스 객체를 활용해서 트루값에 도착한 상태
// 3.rejected : 프로미스 객체를 활용해서 false값에 도착한 상태

//fetch()를 활용하여 데이터 출력해보기
fetch("student.json") //JSON파일을 Promise()객채로 가져옴
  .then(response => response.json()) //JSON파일 -> 객체파일 변환
  .then(json => {
    let output = "";
    json.forEach(student => {
      output += `
        <h2>${student.name}</h2>
        <ul>
          <li>전공 : ${student.major}</li>
          <li>학년 : ${student.grade}</li>
        </ul>
      `
    });
    document.querySelector("#result").innerHTML = output;
  })
.catch(error => console.log(error))