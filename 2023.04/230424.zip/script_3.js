const lastYear = document.querySelector("#year");
const lastMonth = document.querySelector("#month");
const lastDate = document.querySelector("#date");

const btn = document.querySelector("button");

const current = document.querySelector("#current");
const resultDays = document.querySelector("#days");
const resultHours = document.querySelector("#hours");

const today = new Date();
current.innerText = `${today.getFullYear()}년 ${today.getMonth()+1}월 ${today.getDate()}일 ${today.getHours()}시 ${today.getMinutes()}분 현재`

btn.addEventListener("click", (e) => {
  e.preventDefault();

  const lastDay = new Date(lastYear.value, lastMonth.value - 1, lastDate.value);
  let passed = lastDay.getTime() - today.getTime();
  let passedDay = Math.floor(passed / (60 * 60 * 24 * 1000));
  let passedHour = Math.round(passed / (60 * 60 * 1000));

  resultDays.innerText = `날짜로는 ${passedDay}일 남았고,`;
  resultHours.innerText = `시간으로는 ${passedHour}시간이 남았습니다.`;

  lastYear.value = "";
  lastMonth.value = "";
  lastDate.value = "";
});