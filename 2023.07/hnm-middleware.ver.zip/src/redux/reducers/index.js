import { combineReducers } from "redux";
//복수의 리듀서를 하나로 합침
import authenticateReducer from "./authenticateReducer";
import productReducer from "./productReducer";

export default combineReducers({
  auth: authenticateReducer,
  product: productReducer,
});
