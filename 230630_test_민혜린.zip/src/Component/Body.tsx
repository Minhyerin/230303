import React from "react";
import { useState } from "react";
import { styled } from "styled-components";
import Footer from "./Footer";

const Container = styled.div`
  display: flex;
  flex-direction: column;
  gap: 20px;
`;

const InputBox = styled.div`
  display: flex;
  flex-direction: column;
  justify-contents: center;
  gap: 10px;
`;

const LabelStyle = styled.label`
  color: grey;
  display: inline-block;
  font-size: 12px;
`;

const Input = styled.input`
  border: none;
  border-bottom: 1px solid lightgrey;
  outline: none;
  padding: 10px;
  &:focus {
    border-bottom: 1px solid rgb(0, 0, 220);
  }
`;

const GenderCheck = styled.div`
  width: 100%;
  text-align: center;
  margin: 30px 0;
`;

const Agreement = styled.div`
  width: 100%;
  text-align: center;
  line-height: 12px;
`;

const Hr = styled.hr`
  width: 100%;
  border: none;
  border-bottom: 2px solid lightgrey;
`;
const Body = () => {
  const [email, setEmail] = useState("");
  const [userName, setUserName] = useState("");
  const [password, setPassword] = useState("");
  const [passwordCheck, setPasswordCheck] = useState("");

  const handleOnClick = () => {
    if (email && userName && password && passwordCheck) {
      alert("가입을 축하합니다.");
    } else {
      alert("작성란은 모두 입력해주세요");
    }
  };

  return (
    <Container>
      <InputBox>
        <LabelStyle>*이메일</LabelStyle>
        <Input
          onChange={(e) => setEmail(e.target.value)}
          type="email"
          value={email}
        />
      </InputBox>
      <InputBox>
        <LabelStyle>*이름</LabelStyle>
        <Input
          onChange={(e) => setUserName(e.target.value)}
          type="text"
          value={userName}
        />
      </InputBox>
      <InputBox>
        <LabelStyle>*비밀번호</LabelStyle>
        <Input
          onChange={(e) => setPassword(e.target.value)}
          type="password"
          value={password}
        />
      </InputBox>
      <InputBox>
        <LabelStyle>*비밀번호 확인</LabelStyle>
        <Input
          onChange={(e) => setPasswordCheck(e.target.value)}
          type="password"
          value={passwordCheck}
        />
      </InputBox>
      <GenderCheck>
        <input type="radio" name="gender" />
        <label>여성</label>
        <input type="radio" name="gender" />
        <label>남성</label>
      </GenderCheck>
      <Agreement>
        <input type="checkbox" />
        <LabelStyle>
          이용약관 개인정보 수집 및 이용, 마케팅 활용 선택에 모두 동의합니다.
        </LabelStyle>
      </Agreement>
      <Hr />
      <Footer handleOnClick={handleOnClick} />
    </Container>
  );
};

export default Body;
