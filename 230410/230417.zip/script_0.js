const bg = document.querySelector("body")
const btn = document.querySelector("button");

btn.onclick = () => {
  bg.classList.toggle("dark");

  if(!bg.classList.contains("dark")) {
    btn.innerText = "다크모드로 바꾸기"
  } else {
    btn.innerText = "라이트모드로 바꾸기"
  }
}

const select = document.querySelector("#major-box");
const name = document.querySelector("#userName");
function selectMajor() {
  let txt = select.options[select.selectedIndex].text;
  alert(`${name.value}님, ${txt}를 선택했습니다.`);
}

select.onchange = selectMajor;
