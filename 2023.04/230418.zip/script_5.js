// 이름, 전공 데이터와 정의값.
// 버튼의 정의
// 버튼을 누르면 출력되는 공간에 대한 정의

let name = document.querySelector("#name");
let major = document.querySelector("#major");
const save = document.querySelector("#save");


save.addEventListener("click",  (e) => { //버튼을 클릭했을 때
  e.preventDefault(); //버튼 태그의 기본 속성값 삭제

  let tbody = document.querySelector("tbody");
  let newTr = document.createElement("tr"); //tr 태그 생성

  let nameTd = document.createElement("td");
  nameTd.innerText = name.value;
  newTr.appendChild(nameTd);

  let majorTd = document.createElement("td");
  majorTd.innerText = major.value;
  newTr.appendChild(majorTd);

  tbody.appendChild(newTr);
  //newTr.innerHTML = `<td>${name.value}</td><td>${major.value}</td>`; //tr태그 안에 들어가는 td태그, 그안의 요소들 
  //tbody.appendChild(newTr); // table 태그의 하위 요소로 넣기

  name.value = ""; // 입력된 후에 인풋박스 값 지우기
  major.value = ""; 
});

