const a = 1;
console.log("hello")