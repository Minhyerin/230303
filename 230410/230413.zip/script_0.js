// ===== for of()문 : 문자열 혹은 배열객체에서 반복가능한 반복문
// for in() 과 fot of() 차이 : in()일반객체에서 객체의 값을 가져와서 반복처리, of() 배열객체에서 각각의 변수값을 가져와서 반복처리할때(=forEach)
/*
const students = ["park", "kim", "kang", "lee"];
for(let student of students) {
    document.write(`${student}.`);
}
*/

// ==== while / do while : 
// while : 조건이 참인 경우 문장을 반복
/*
while(조건) {
  실행할 명령
}
// do while : 참 거짓 여부와 상관없이 무조건 1회 반복후 조건식 참고.
do {
  실행할 명령
} while (조건)

let stars = parseInt(prompt("별의 갯수"));
// while(stars > 0) {
//   document.write("*")
//   stars--;
// }
do {
  document.write("*");
  stars--;
} while(stars > 0)
*/

// ==== break / continue
// break : 반복문을 강제 종료
// continue : 특정조건에 해당되는 값을 만났을때 실행하던 반복 문장을 건너뛴다.

//소수: 1과 자기자신으로 밖에 나눌 수 있는 수.
/*
const number = parseInt(prompt("숫자를 입력하세요"));
let isPrime; 

if(number === 1) {
  document.write(`${number}은 소수도 합성수도 아닙니다.`);
} else if(number === 2) {
  isPrime = true;
} else {
  for(let i = 2; i < number; i++) {
    if(number % i === 0) {
      isPrime = false;
      break;
    } else {
      isPrime = true;
    }
  }
};

if(isPrime) {
  document.write(`${number}는 소수입니다.`);
} else {
  document.write(`${number}는 소수가 아닙니다.`);
}; */

/*
const num = [1, 3, 5, 7, 9, 11, 13, 15, 17, 19];

for(let i = 0; i < num.length; i++) {
  if(num[i] > 10) {
    document.write(`${num[i]}. `);
  };
};
*/
/*

// =====================================7 입력 => 2+4+6의합을 출력
const number = parseInt(prompt("1보다 큰 숫자를 입력하세요"));
let a = 0;

if(number != null) { //값이 입력된다면
  for(let i = 2; i <= number; i++){ // i는 2부터 입력받은 값보다 작은수까지 반복 2,3,4,5,6
    if(i % 2 == 0) { // 그 i값이 짝수라면. 2,4,6
      a += i; // a의 변수에 i값을 더한다.
    } 
  }
} 
document.write(`입력한 값보다 작은 짝수들의 합은 ${a} 입니다`);
*/
//=======================================
/*
let n = parseInt(prompt("1보다 큰 숫자를 입력하세요."));
let sum = 0;

if(n !== null && n > 1) {
  for(let i = 1; i <= n; i++) {
    if(i % 2 == 1) {
      continue;  // 홀수일경우엔 컨티뉴로 뛰어넘음.
    } sum += i; //짝수일때 더함.
    document.write(`${i}------${sum} <br/>`)
  }
}
*/

//====================================== 함수
// 변수: 바구니, 객체 : 다양한 정보들의 집합체 , 함수: 여러개의 명령들을 묶어놓은 것.
// 함수를 사용해야하는 이유
// 1. 사용자의 요구사항이 천차만별이다.
/*
함수이름 () => 함수.
함수생성 = 함수 선언
함수호출
*/
/*
function 함수명(매개변수) {
  실행명령문
} => 함수선언

함수명(매개변수) => 함수호출
*/
/*
function calcSum() {
  let sum = 0;
  for(let i = 0; i <= 10; i++){
    sum += i
  }
  console.log(`1부터 10까지 더하면 ${sum}`);
}
calcSum(); 
*/
//사용자로부터 특정 값을 받아서 함수를 실행하고 싶으면 매개변수가 필요하다 (가변함수)
// 매개변수에 전달될 값 = 인수 또는 인자값.
/*
let a = parseInt(prompt("첫번째 값"));
let b = parseInt(prompt("두번째 값"));

function sum(a,b) {
  let result = a + b;
  alert(`두 수의 합: ${result}`);
}
sum(a,b);
*/
/*
let n = parseInt(prompt("값을 입력하세요"));

function calcSum(n){
  let sum = 0;
  for(let i = 0; i <= n; i++){
    sum += i
  }
  console.log(`1부터 ${n}까지의 더하면 ${sum}입니다.`);
}
calcSum(n);
*/
/*
function calcSum(n) {
  let sum = 0;
  for(let i = 1; i <= n; i++){
    sum += i; //반환값을 정의해줘야함. :함수를 호출했을때 어떤 값을 불러올 것인지.
  }
  return sum; //함수를 호출했을때 sum의 값을 가지고온다.
}
let num = parseInt(prompt("몇까지 더할까요?"));
document.write(`1부터 ${num}까지 더하면 : ${calcSum(num)}`); //함수호출 : sum 값을 보여줌.
*/
// =======================================
/*
let num1 = parseInt(prompt("첫번째 값을 입력하세요"));
let num2 = parseInt(prompt("두번째 값을 입력하세요"));

function calcSum(a, b) {
  return a * b;
}
document.write(`${num1} 곱하기 ${num2}(은)는 ${calcSum(num1, num2)}입니다.`);
*/
/*
function multiple(a, b = 5, c = 10){ //매개변수의 기본값.지정.
  return a * b + c;
}
console.log(multiple(2,5,10));
console.log(multiple(10, 20));
console.log(multiple(10)); //사용자가 값을 지정하지 않았다면 함수에서 매개변수의 기본값을 가져옴.
*/
/*
function calcSum(n) {
  let sum = 0;
  for(let i = 1; i <= n; i++) {
    sum += i;
  }
  console.log(`1부터 ${n}까지 더하면 ${sum}입니다.`)
}
calcSum(10);
*/

//함수스코프 = 적용범위 > 함수가 영향을 미칠 수 있는 적용범위
// 1.지역스코프(로컬) 2.전역스코프(전역)
/*
let hi = "hello";

function change() {
    hi = "bye";
}
console.log(hi);
*/
// 전역변수 사용방법
// 1코드를 작성할때 가장 최상단에 변수선언, 값 할당
// 2 함수안에 변수를 작성할때 변수를 정의하는 키워드 = 예약어를 생략한다.
/*
const factor = 5;

function clac(num) {

  return num * factor;
}
{
let result = clac(10); // 블록 스코프 
document.write(`result :  ${result}`)
}
*/

// 변수 var let const 의 차이점?
//바는 브라우저 객체 모델에도 영향을 미칠수있는 전역변수로 영향을 미칠 수 있으므로 불필요한 메모리 공간을 사용할 수 잇음..
//렛 콘스트는 스크립트 스코프임 = 스크립트에만 영향을 줄 수잇음.

// function addSum(n) {
//   var sum = 0;
//   for(var i = 1; i <= n; i++) {
//     sum += i;
//   }
//   return sum;
// }

// var num = 3;
// console.log(`1부터 ${num} 까지 더하면 ${addSum(num)}`);

// function addSum(n) {
//   let sum = 0;
//   for(let i = 1; i <= n; i++) {
//     sum += i;
//   }
//   return sum;
// }

// const num = 3;
// console.log(`1부터 ${num} 까지 더하면 ${addSum(num)}`);


//======익명함수 : 함수명을 정의 하지 않은 것.
/*
let sum = function(a, b) {  //변수의 이름이 함수의이름을 대체하게 된다. 이 변수의 이름을 참조변수라 한다.
}*/

// 자바스크립트 함수를 1급 함수라 한다.
// 함수를 익명으로 선언 가능, 함수를 변수 값으로 할당 할 수 있어서.

//=====즉시실행 함수 : 함수를 정의하면서 동시에 실행시키는 함수

/*
(function(매개변수) {

}, 인자값)
*/

/*
(function(a,b) {
  let sum = a + b;
  console.log(`함수 실행 결과 ${sum}`);
}(100, 200));
*/

//====== 화살표 함수
/*
// 1. 매개변수가 없을때 화살표 함수 사용법
let hi = function() {
  return '안녕하세요'
}
let hi = () => {return '안녕하세요'}
let hi = () => '안녕하세요'

// 2 매개변수가 하나일때 화살표 함수 사용법
let hi = user => console.log(`${user}, 안녕하세요`)

// 3. 매개변수 두개일떄 화살표 함수 사용법.
let sum = (a, b) => a + b;
sum(10, 20);
*/

// ======= 콜백함수 : 함수안에 인수가 되는 또다른 함수.
//const btn = document.querySelector("button");
/*
function display() {
  alert("클릭했습니다.");
}
btn.addEventListener("click", display);
*/ //display = 콜백함수
//이벤트 함수 한에 들어가는 인자값으로, 콜백함수

// ===> 간단하게 작성하는 방법.
// btn.addEventListener("click", () => {
//   alert("클릭했습니다.");
// });

/*
let a = parseInt(prompt("첫번째 값"));
let b = parseInt(prompt("두번째 값"));

let sum = (a, b) => a * b;
console.log(sum(a, b));
*/
/*
function showData(name, age){
  alert(`안녕하세요 ${name}님, 나이가 ${age}살 이군요`);
}

function getData(callback) {
  let userName = prompt("이름을 입력하세요");
  let userAge = parseInt(prompt("나이를 입력하세요"));
  callback(userName, userAge);
}
//===> 이해안됨..
getData(showData);
*/

//fruits = ["사과", "배", "오렌지"];
//(3) ['사과', '배', '오렌지']
//console.log(...fruits); ==> 값만 보고 싶을때.
// ==> 사과 배 오렌지

/*
function addNum(a, b){
  return a + b;
}
undefined
addNum(1, 3);
4
addNum(1,3,5,7);
4
*/
/*
function displayFavotites(first,...favs){ //다른 인자값도 받긴 받아줌
  let str = `가장 좋아하는 과일은${first}군요`;
  return str;
}
console.log(displayFavotites("사과", "포도", "토마토")); 
1 가장 좋아하는 과일은사과군요
*/


//===========setInteval(콜백함수, 시간): 일정한 시간마다 함수를 반복해서 실행, 자바스크립트는 밀리초 사용, (1000밀리초 = 1초) <==> clearInteval
/*
function greeting() {
  console.log('안녕하세요');
}

setInterval(greeting, 2000);
*/
/*
let timer = setInterval(()=> {
  console.log('안녕하세요');
}, 2000);

clearInterval(timer);
*/
/*
let counter = 0;

let timer =  setInterval(()=> {
  console.log('안녕하세요')
  counter++; //변수가 같이 증가. 근데 5가되면.
  if(counter == 5) {
    clearInterval(timer);
  }
}, 2000);
*/

//=========setTimeout(콜백함수, 딜레이시간) : 딜레이 시간 후 콜백함수 실행
/*
setTimeout(()=> {
  console.log('hi')
}, 3000)
*/

//사용자에게 숫자를 받아서 해당 숫자를 함수로 넘겨준 뒤, 해당 함수에서는 숫자가 양수 인지, 음수인지, 또는 0 인지 판단해서, 알림창을 통해 알려주는 프로그램
// 1. 숫자를 받는다.
// 2. 숫자일 경우에만 함수 실행.
// 3. 숫자가 양수, 음수, 0 조건에 따라 메세지를 다르게 출력한다.
// inNan(매개변수) : 매개변수가 숫자인지 아닌지를 검사하는 함수.
/*
const number = parseInt(prompt('숫자를 입력하세요'));

if(!isNaN(number)) { //숫자라면 
  isPositive(number);
}
function isPositive(number) {
  if(number > 0) {
    alert(`${number}는 양수입니다.`);
  } else if (number < 0) {
    alert(`${number}는 음수입니다.`);
  } else {
    alert(`${number}은 0입니다.`)
  }
}
*/