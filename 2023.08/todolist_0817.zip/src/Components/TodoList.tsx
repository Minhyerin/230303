import React, { useState } from "react";
import { useRecoilState, useRecoilValue } from "recoil";
import { todoState, todoSelector, categoryState } from "./Atoms";
import CreateTodo from "./CreateTodo";
import Todo from "./Todo";

const TodoList = () => {
  const todos = useRecoilValue(todoSelector);
  const [category, setCategory] = useRecoilState(categoryState);
  const onInput = (event: React.FormEvent<HTMLSelectElement>) => {
    setCategory(event.currentTarget.value);
  };
  console.log(category);
  return (
    <div>
      <h1>To Do's</h1>
      <hr />
      <select value={category} onInput={onInput}>
        <option value="TO_DO">To do</option>
        <option value="DOING">Doing</option>
        <option value="DONE">Done</option>
      </select>
      <CreateTodo />
      {todos?.map((todo) => (
        <Todo key={todo.id} {...todo} />
      ))}
      {/* {category === "TO_DO" &&
        todos.map((aTodo) => <Todo key={aTodo.id} {...aTodo} />)}
      {category === "DOING" &&
        doing.map((aTodo) => <Todo key={aTodo.id} {...aTodo} />)}
      {category === "DONE" &&
        done.map((aTodo) => <Todo key={aTodo.id} {...aTodo} />)} */}
    </div>
  );
};

export default TodoList;
