export function srting2(str2) {
  let newP2 = document.createElement("p");
  newP2.innerText = str2;
  document.querySelector("#log").appendChild(newP2);
};