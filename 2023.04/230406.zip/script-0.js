$(function() {
  $("#wrap a[target]")
  .css({
    "color" : "#f00"
  });

  $("#wrap a[href^=https]")
  .css({
    "color" : "#0f0"
  });

  $("#wrap a[href$=net]")
  .css({
    "color" : "#fff",
    "background-color" : "#000" 
  });

  $("#wrap a[href*=google]")
  .css({
    "color" : "#000"
  });

  $("#member_f :text")
  .css({
    "background-color" : "#ff0"
  })

  $("#member_f :password")
  .css({
    "background-color" : "#0ff"
  });
})