// 비동기프로그래밍
// function displayA() {
//   console.log("A");
// };
// function displayB() {
//   setTimeout(() => {
//     console.log("B");
//   }, 2000);

// };
// function displayC() {
//   console.log("C");
// };


// displayA();
// displayB();
// displayC();
// 싱글 스레드(*실) 
// 스레드 : 프로그램에서 어떠한 프로세를 실행하는 단위를 가리킴, 한번에 하나의 프로세스를 실행한다면, 단일 혹은 싱글 스레드. 한번에 여러개의 프로세스를 실행한다면 멀티 스레드

//콜백함수 : 자바스크립트의 비동기 처리방식을 위한 필수요소! (멀티스레드의역할) *함수안에 인자값으로 들어가는 또다른 함수.
// function displayA() {
//   console.log("A");
// };
// function displayB(callback) {
//   setTimeout(() => {
//     console.log("B");
//     callback();
//   }, 2000);
// };
// function displayC() {
//   console.log("C");
// };


// displayA();
// displayB(displayC);


function order(coffee, callback) {
  console.log(`${coffee} 주문접수`)
  setTimeout(() => {
    callback(coffee);
  }, 2000)
}
function display(result) {
  console.log(`${result} 준비완료`)
}

order("아메리카노", display);