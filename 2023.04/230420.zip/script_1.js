//원 넓이 구하기 : 반지름 * 반지름 * 원주율
//원 둘레 구하기 : 반지름 * 2 * 원주율

// 결과 값을 출력해야하는 공간에 대한 정의
// 원의 넓이를 구하는 공식에 대한 정의 (함수)
// 원의 둘레를 구하는 공식에 대한 정의 (함수)
// 반지름 = 사용자로부터 값 받기.

const result = document.querySelector("#result");
const radius = parseInt(prompt("반지름의 크기는?"));

// 원의 넓이를 구하는 함수
function area(r) {
  return Math.PI * r * r
};

//원의 둘레를 구하는 함수
function circum(r) {
  return Math.PI * r * 2
};

result.innerText = `
  반지름 : ${radius} 
  원의넓이 : ${area(radius).toFixed(3)}
  원의둘레 : ${circum(radius).toFixed(3)}
  `;