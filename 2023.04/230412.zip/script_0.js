// function random(number) {
//   return Math.floor(Math.random() * number);
// }
// function bgChange() {
//   const rndCol = 'rgb(' + random(255)+ ',' + random(255) + ' , ' + random(255) + ')';
//   document.body.style.backgroundColor = rndCol;
// } 
// bgChange();
// 바디 컬러 변경

//null은 값이다. 아무것도 아닌 값.
//undefined 정의되지않았다. 아예 형태자체도 없음.

// let name = prompt('당신의 이름은?');
// let classRoom = prompt('입장하고 싶은 강의실은?', '201');
// document.write(name + "님 " + classRoom + "호 강의실로 입장하세요!", "<br/>");
// document.write(`${name}님 ${classRoom}호 강의실로 입장하세요!`);

//  객체형태 : 객체명 = {
//  key : value,
//  key : value,
//  key : value
// }
// key : value => 한쌍 = property

// let book = {
//   title : "javascript",
//   page : 200,
//   pubDate : "2023-04-12"
// };

// book.title;
// 'javascript'
// book["pubDate"];
// '2023-04-12'

// let item = {
//   brand : "스타벅스",
//   name : "미르 사이렌 민트 텀블러",
//   color : "민트",
//   height : "591ml",
//   price : 35000,
//   delP : "무료",
//   del : "CJ대한통운"
// }

// console.log(`${item['brand']}의 ${item['name']}는 ${item['color']}색이고, 가격은 ${item['price']}원입니다.`)

// Symbol() : 함수 , 객체의 자료중 유일한 혹은 유니크한 키 값을 부여하고 싶을 때 사용하는 함수.

//Number() - 문자열을 숫자열로 바꿔줌.
//parseInt() - 문자열을 숫자열로 바꿔줌.
//parseFloat() - 문자열을 숫자열로 바꿔줌.

//다른 타입의 자료형을 문자열로 변환할때 사용하는 함수는 String();
//간단하게 숫자나 문자열로 변환하는 방법
// 변수명 = +변수명 으로 재 정의. => 숫자형
// 변수명 = 변수명 + ""; => 문자열

//다른 유형의 데이터를 논리형 데이터로 변환하고 싶다면,
// Boolean() => 논리형

/* ===== 정리 ====
1. 스크립트 입력방법 인라인 내부 외부
2. 기본내장 함수 3가지 alert, prompt, confirm
3. 변수 = 바구니 > var, let, const
4. 자료형 숫자, 논리형, 문자형
5. 객체 , 배열객체 key, value, property, Symbol()
6. 자료형 변환방법
- 문자 => 숫자 Number(), parseInt(), parseFloat()
- 숫자 => 문자 String()
- 논리 => Boolean()
*/


// let data1 = parseInt(prompt("화씨온도를 입력하세요"));
// let data2 = ((data1 - 32) / 1.8);
// let result = (data2).toFixed(1); 소수점(1)까지 나온다

// document.write(`화씨 ${data1}도는 섭씨 ${result}도 입니다.`)

// ========== 산술 연산자 ( +, -, *, /, %, 증감연산자)
// + 연산자, 피연산자 (연산자가 아닌 값)
// 증감연산자 : 연산자가 피 연산자 앞에 있으면 식을 행하기 전에 증감, 뒤에있으면 식을 수행하곡 증감.

// ========== 대입 연산자 (할당연산자)
// y = y + x => y += x

// ========== 비교 연산자 (>,>=,<,<=, ==, ===)
// == 값이 같다, === 값과 속성이 같다.
// !==, != 부정연산자
// 3 == "3"
// true
// 3 != "3"
// false
// 3 !== "3"
// true
// 3 === "3"
// false

// ========= 논리 연산자 (참, 거짓) &&(그리고), || (혹은)

// ==== 제어문 ==== (if(else), else-if, for of-in, switch, (do)while, continue, break)

// ========= if(조건식) { 조건식이 참일 경우, 실행할 명령값} else{위 조건식이 거짓일 경우 실행활 명령값}
// let userInput = prompt('이름을 입력하세요');
// if(userInput === null) {
//     alert('취소했습니다.');
// } else {
//   alert(userInput);
// }

// let score = prompt('프로그래밍점수입력');
// undefined
// if (score != null) {
//     if(score >= 90) {
//         alert("a");
//     } else if(score >= 80) {
//         alert("b"); 
//     } else {
//         alert("c");
//     }
// }

// ==== 조건문에서 중괄호 생략 언제하는가
// 1. false 값을 설정하지 않은 경우
// 2. 줄 코딩을 할 만큼 간단한 조건식일 경우

// =========== 삼항 조건 연산자. 
// 조건 ? 참일때 실행할 명령문 : 거짓일때 실행할 명령문
/*
if (num1 < num2) {
  small = num1;
} else {
  small = num2;
} =====>
small = (num1 < num2) ? num1 : num2;
*/

/*
let num = parseInt(prompt('숫자를 입력하세요'));

if(num == null) {
  (num % 2 === 0) ? alert(num + "짝수입니다.") : alert(num + "홀수입니다.")
} alert("값을 입력하지 않았습니다.")
*/
//짝수, 홀수가 뿐만 아니라 값이 입력되지 않았을 때도 고려해야 함!!! *prompt 로 받는 값이 숫자형이여야 할때 꼭 문자형 => 숫자형으로 변환해줘야 함.


// ======== switch문 
/*
let subject = prompt('신청할 과목을 선택하세요 1-html, 2-css, 3-javascript');
if(subject !== null) {
  switch(subject) {
    case "1" : document.write('html을 신청했습니다.');
    break;
    case "2" : document.write('css을 신청했습니다.');
    break;
    case "3" : document.write('javascript을 신청했습니다.');
    break;
    default : document.write('잘못입력했습니다.')
    
  }
} */

/*
const num1 = parseInt(prompt("첫번째 정수 : "));
const num2 = parseInt(prompt("두번째 정수 : "));
let str;
if(num1 % 2 == 0 && num2 % 2 == 0) {
  str = "두 수 모두 짝수 입니다."
} else {
  str = "짝수가 아닌 수가 있습니다."
}
alert(str);
*/


// ========== for문 기본형
//for(초기값; 조건식; 증감문) { 실행문 }

/*
const students = ["Park", "Kim", "Lee", "Kang"];

for(let i = 0; i < students.length; i++) {
  document.write(`${students[i]}, `);
} */
/*
const colors = ["black", "white", "yellow", "pink"];

for(i = 0; i < colors.length; i++) {
  document.write(`${colors[i]}, `)
} */

// ========= forEach() 함수 : "배열 객체"에서 각각의 요소들을 꺼내서 반복시키고자 할때 사용
// forEach(콜백함수) : 콜백함수란? 다른 함수의 인자값으로 사용되는 함수를 의미. 인자값이란? 인수라고도함. 매개변수의 값으로 적용될 값. 매개변수란? 함수의 안에 들어가야하는 값.(함수가 작동하기위해 존재해야하는 값., = 코인)
/*
const students = ["park", "lee", "kim", "kang"];

students.forEach(function(student) { 
  document.write(`${student}. `);
})*/
/*
const fruits = ["사과", "딸기", "포도", "오렌지"];

fruits.forEach(function(fruit) {
  document.write(`${fruit}. `);
})*/

// ========= for in()문 : "일반 객채"에서 객체안에 있는 프로퍼티 값*(key : value)을 가져와서 반복시킬 때 사용
// for(변수 in 객체명){ }

const bookInfo = {
  title : "javascript",
  pubDate : "2023-04-12",
  pages : 272,
  finished  : true
};

for(let i in bookInfo) {
  document.write(`${i} : ${bookInfo[i]} <br/>`)
}
