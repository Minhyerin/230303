import React, { useState } from "react";
import { useForm } from "react-hook-form";

// const TodoList = () => {
//   const [todo, setTodo] = useState("");
//   const [todoError, setTodoError] = useState("");
//   const onChange = (event: React.FormEvent<HTMLInputElement>) => {
//     const {
//       currentTarget: { value },
//     } = event;
//     setTodo(value);
//     setTodoError("");
//   };
//   const onSubmit = (event: React.FormEvent<HTMLFormElement>) => {
//     event.preventDefault();
//     console.log(todo);
//     if (todo.length < 5) {
//       return setTodoError("To do should be longer...");
//     } else {
//       setTodo("");
//     }
//   };
//   return (
//     <div>
//       <form onSubmit={onSubmit}>
//         <input onChange={onChange} value={todo} placeholder="write a todo" />
//         <button>add</button>
//         {todoError !== "" ? todoError : null}
//       </form>
//     </div>
//   );
// };

interface IForm {
  todo: string;
}

const TodoList = () => {
  const {
    register,
    handleSubmit,
    formState: { errors },
    setValue,
  } = useForm<IForm>();
  const handleValid = (data: IForm) => {
    setValue("todo", "");
    console.log(data.todo);
  };
  return (
    <div>
      <form onSubmit={handleSubmit(handleValid)}>
        <input
          {...register("todo", { required: "Please write a Todo" })}
          placeholder="write a todo"
        />
        <button>add</button>
        <span>{errors.todo?.message as string}</span>
      </form>
    </div>
  );
};

// interface IForm {
//   email: string;
//   firstName: string;
//   lastName: string;
//   userName: string;
//   password: string;
//   password1: string;
// }

// const TodoList = () => {
//   const {
//     register,
//     handleSubmit,
//     watch,
//     formState: { errors },
//     setError,
//   } = useForm<IForm>();
//   const onValid = (data: IForm) => {
//     if (data.password !== data.password1) {
//       setError(
//         "password1",
//         { message: "password is not the same" },
//         { shouldFocus: true }
//       );
//     }
//     console.log(data);
//   };
//   return (
//     <form onSubmit={handleSubmit(onValid)}>
//       <input
//         {...register("email", {
//           required: "email is required",
//           pattern: {
//             value: /^[A-Za-z0-9]+@naver.com/gm,
//             message: "only naver.com emails allowed",
//           },
//         })}
//         placeholder="email"
//       />
//       <span>{errors.email?.message as string}</span>
//       <input
//         {...register("firstName", {
//           required: "write here",
//           validate: (value) => !value.includes("test"),
//         })}
//         placeholder="firstName"
//       />
//       <input {...register("lastName")} placeholder="lastName" />
//       <input
//         {...register("userName", { minLength: 2 })}
//         placeholder="userName"
//       />
//       <input
//         {...register("password", {
//           minLength: { value: 5, message: "password to short" },
//         })}
//         placeholder="password"
//       />
//       <span>{errors.password?.message as string}</span>
//       <input {...register("password1")} placeholder="password1" />
//       <span>{errors.password1?.message as string}</span>
//       <button>add</button>
//     </form>
//   );
// };

export default TodoList;
