//예외처리 try catch throw

const number = document.querySelector("#number");
const btn = document.querySelector("button");
const result = document.querySelector("#result");

btn.addEventListener("click", (e)=> {
  e.preventDefault();
  let n = number.value;
  try {
    if(n == "" || isNaN(n)){
      throw "숫자를입력하세요"
    }
    if(n <= 10){
      result.innerHTML = n;
    }
    if(n > 10) {
      throw "10보다 큰 숫자를 입력했습니다." //throw = arr
    }
  } catch(err) {
      result.innerHTML = n + " : "+ err;
      alert(err);
  } finally { //(선택사항) 에러가 있던지 없던지 이 실행문으로 끝남.
    number.value = "";
  }
});
