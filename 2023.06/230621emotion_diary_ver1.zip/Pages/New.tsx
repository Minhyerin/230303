const New = () => {
  return (
    <div>
      <div>New페이지 입니다.</div>
    </div>
  );
};

export default New;
