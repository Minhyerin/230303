//수학객체
// let num =  2.1234;
// let maxNum = Math.max(10, 5, 8, 30); //max는 최대값을 반환하는 함수
// let minNum = Math.min(10, 5, 8, 30); //min는 최소값을 반환하는 함수
// let roundNum = Math.round(num); //round 반올림
// let floorNum = Math.floor(num); //floor 소수점 첫번째자리에서 무조건 내림
// let ceilNum = Math.ceil(num); //ceil 소수점 첫번째자리에서 무조건 올림
// let randomNum = Math.random(); //random 값이 바뀜(최대값이 0.9999999임 1을 넘지않음. = 즉 실수값)
// let piNum = Math.PI; // 원주율

// document.write(maxNum, "<br />");
// document.write(minNum, "<br />");
// document.write(roundNum, "<br />");
// document.write(ceilNum, "<br />");
// document.write(randomNum, "<br />");
// document.write(piNum, "<br />");

//예제
// let menu = ["짜장밥", "돈까스", "국밥", "김치찌개", "회덮밥"];

// let menuNum = Math.floor(Math.random()*menu.length);
// let result = menu[menuNum];

// document.write(result);

//예제 가위바위보 1탄
let game = prompt("가위 바위 보 중 선택하세요!", "가위");
let gameNum;

switch(game) {
  case "가위" : gameNum = 1;
  break;
  case "바위" : gameNum = 2;
  break;
  case "보" : gameNum = 3;
  break;
  default : alert("잘못 작성했습니다😒");
  location.reload();
}

let com = Math.ceil(Math.random()*3);
document.write("<img src=\"/img/math_img_" + com + ".jpg\">");

if(gameNum == com) {
  document.write("<img src=\"/img/game_1.jpg\">");
} else {
  document.write("<img src=\"/img/game_2.jpg\">");
}