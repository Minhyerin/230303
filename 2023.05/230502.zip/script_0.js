const canvas = document.querySelector("canvas");
const ctx = canvas.getContext("2d");

canvas.width = window.innerWidth;
canvas.height = window.innerHeight;

// //  destination
// ctx.fillStyle = "#ccc";
// ctx.fillRect(100, 50, 100, 100);

// ctx.globalCompositeOperation = "darken";
// // glovalCompositeOperation
// // 1) source-over :  소스로 시작하는 그래픽 요소를 데스티네이션 요소 위쪽에 배치
// // 2) source-in :  소스를 그리면서 데스티네이션 요소와 겹쳐지는 부분만 그리고 나머지는 투명하게 처리
// // 3) source-out :  소스를 그리면서 데스티네이션 요소와 겹쳐지지 않는 부분만 그린다.
// // 4) source-atop :  소스를 그리면서 데스티네이션 요소와 겹쳐지는 부분을 그리고, 그 외 데스티네이션은 불투명하게 처리 

// // source
// ctx.fillStyle = "lightBlue";
// ctx.beginPath();
// ctx.arc(180, 120, 50, 0, Math.PI * 2, false);
// ctx.fill();
// // 서로다른 두개의 도형이 중첩되어있을때, 먼저 작성된 도형을 destination, 나중에 작성된 도형을 source

// ctx.beginPath();
// ctx.font = "bold 280px sans-serif";
// ctx.fillText("GOOD", 100, 320);

// ctx.globalCompositeOperation = "source-in";

// ctx.beginPath();
// let img = new Image();
// img.onload = function() {
//   ctx.drawImage(img, 0, 0, 1200, 600);
// };

// img.src = "/image/flower.jpg";

// function Circle(x, y, radius, color) {
//   this.x = x;
//   this.y = y;
//   this.radius =  radius;
//   this.color = color;

//   this.draw = function() {
//     ctx.beginPath();
//     ctx.fillStyle = this.color;
//     ctx.arc(this.x, this.y, this.radius, 0, Math.PI * 2, false);
//     ctx.fill();
//   }
// }

// const objs = [];
// for(let i = 0; i < 20; i++) {
//   const radius = Math.floor((Math.random() * 50)) + 10;
//   const x = Math.random() * (canvas.width - radius * 2) + radius; 
//   const y = Math.random() * (canvas.height - radius * 2) + radius; 
//   const color = `rgb(${Math.random() * 255}, ${Math.random() * 255}, ${Math.random() * 255})`
//   objs.push(new Circle(x, y, radius, color));
// }

// for(let i = 0; i < objs.length; i++) {
//   objs[i].draw();
// };

//기초애니메이션 원리
// const circle = {
//   x : 100,
//   y : 100,
//   radius : 30,
//   dx : 10,
//   dy : 7,
//   color : "#222"
// };

// function drawCircle() {
//   ctx.fillStyle = circle.color;
//   ctx.beginPath();
//   ctx.arc(circle.x, circle.y, circle.radius, 0, Math.PI * 2, false);
//   ctx.fill();
// };

// function move() { 
//   ctx.fillStyle = "rgba(255, 255, 255, 0.3)";
//   ctx.fillRect(0, 0, canvas.width, canvas.height);
//   // ctx.clearRect(0,0, canvas.width, canvas.height); //리셋함수로 넣기
//   drawCircle();

//   circle.x += circle.dx;
//   circle.y += circle.dy;
//   if(circle.x + circle.radius > canvas.width || circle.x - circle.radius < 0 ) {
//     circle.dx = -circle.dx;
//   }
//   if(circle.y + circle.radius > canvas.height || circle.y - circle.radius < 0 ) {
//     circle.dy = -circle.dy;
//   }
//   requestAnimationFrame(move);
// }

// move();

function Circle(x, y, radius, color) {
  this.x = x;
  this.y = y;
  this.radius = radius;
  this.color = color;

  this.dx = Math.floor(Math.random() * 4) + 1;
  this.dy = Math.floor(Math.random() * 4) + 1;

  this.draw = function() {
    ctx.fillStyle = this.color;
    ctx.beginPath();
    ctx.arc(this.x, this.y, this.radius, 0, Math.PI * 2, false);
    ctx.fill();
  }
  
  this.animate = function() {
    this.x += this.dx;
    this.y += this.dy;

    if(this.x + this.radius > canvas.width || this.x - this.radius < 0) {
      this.dx = -this.dx;
    }
    if(this.y + this.radius > canvas.height || this.y - this.radius < 0) {
      this.dy = -this.dy;
    }

    this.draw();
  }
}

const objs = [];
for(let i = 0; i < 30; i++) {
  const radius = Math.floor((Math.random() * 50) + 10);
  const x = Math.random() * (canvas.width - radius * 2) + radius;
  const y = Math.random() * (canvas.height - radius * 2) + radius;
  const color = `rgba(${Math.random()* 255}, ${Math.random()* 255}, ${Math.random()* 255}, ${Math.random() * 1})`;
  objs.push(new Circle(x, y, radius, color));
}

function update() {
  ctx.clearRect(0, 0, canvas.width, canvas.height);
  for(let i = 0; i < objs.length; i++) {
    let obj = objs[i];
    obj.animate();
  }
  requestAnimationFrame(update); //재귀함수
}
update();